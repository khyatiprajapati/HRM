<?php
//include("include/session.php");
include("connection.php");
$msg="";
$cn=getCon();
if(isset($_REQUEST['btnsubmit']))
{
	insertData("user_contact","Contact_ID","");
	$msg="<div class=\"message success\"><h5>Success!</h5><p>Data Save Successfully.</p></div>";
	
}
?>
<html>
<head>
<title>Usersite | Contact</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/georgia.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/validation.js" type="text/javascript"></script>

<link href="cssdate/themes/base/jquery.ui.all.css" rel="stylesheet" type="text/css" />
<script src="cssdate/jquery-1.6.4.min.js" type="text/javascript"></script>
<script type="text/javascript" src="cssdate/jquery-ui/jquery.ui.core.min.js"></script>
<script src="cssdate/jquery-ui/jquery.ui.datepicker.min.js" type="text/javascript"></script>
<script src="cssdate/setup.js" type="text/javascript"></script>
</head>
<body>
<div class="main">
 <?php include("header.php");?>
	<?php include('fixsidemenu1.php');?>
  <div class="body">
    <div class="headert_text_resize_bg">
      <div class="headert_text_resize"> 
    <div class="body_resize">
      <div class="left" style="width:600px;margin-left:10px;">
        <h2>Contact Us</h2>
         <form method="post" id="contactform" onSubmit="return validate(this);" enctype="multipart/form-data">
         <ol>
         <li><?php
         echo $msg;  ?>
         </li>
            <li>
              <label>Enter User Name</label>
              <label>:</label>
              <input id="txtUser_Name" name="txtUser_Name" class="text"  />
               <li>
              <label></label>
              <div id="txtUser_Name1"></div>
             </li>
            <li>
              <label>Enter Email ID</label>
              <label>:</label>
              <input id="txxEmail_ID" name="txxEmail_ID" class="text" />
               <li>
              <label></label>
              <div id="txxEmail_ID1"></div>
            </li>
            <li>
              <label>Enter Subject</label>
              <label>:</label>
              <input id="txtSubject" name="txtSubject" class="text"  />
               <li>
              <label></label>
              <div id="txtSubject1"></div>
             </li>
            <li>
              <label>Your Message</label>
              <label>:</label>
               <textarea name="txtMessage" style="width:280px" id="txtMessage" class="textarea"></textarea>
              <li>
              <label></label>
			  <div id="txtMessage1"></div>
              </li>
           <li class="buttons">
             <input class="submit" type="submit" name="btnsubmit" value="SUBMIT" style="margin-left:300px;width:100px;height:35px">
              <input class="submit" type="reset" name="btnreset" value="RESET" style="width:100px;height:35px;margin-left:15px;">              
            </li>
          </ol>
        </form>
      </div>
      <div class="right_resize" style="margin-right:25px;">
        <div class="right" >
          <h2><span>Contact Information</span></h2>
         
            <p align="justify" style="color:#060">62, Smarat Township Socitey,
			</p><p align="justify" style="color:#060">Pravat Patia, Surat.
			</p>
          <!-- <div class="cleaner h30"></div>-->
            
            <div id="map">
                <h4 style="color:#0000FF">Map</h4>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14880.232436500442!2d72.8653385!3d21.18985045!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04fb09f6e05d5%3A0x7f1297a24491d240!2sParvat+Patiya!5e0!3m2!1sen!2s!4v1396370101557" width="250" height="100" frameborder="0" style="border:0"></iframe>
            </div>
            <h4 style="color:#0000FF">Our Location</h4>
                
                	<h6 style="color:#060">Mailing Address</h6>
                   	  	<div style="color:#060">HRM@softmaxsolution.com<br />
                		<br />
                     	Tel: 0261-2314561<br />
                        Fax: 010-020-5500
						</div>
        
         
        </div>
          </div>
       </div>
	   </div>
	   </div>
       <div class="clr"></div>
    </div>
  </div>
 
    <div class="clr"></div>
  </div>
   <?php include('footer.php');?>
</div>
</body>
</html>
