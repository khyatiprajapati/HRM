
<!doctype html>

<head>
<link rel="stylesheet" type="text/css" href="iconmenu.css" />
<link href="jquerysctipttop.css" rel="stylesheet" type="text/css">
<link href="font-awesome.css" rel="stylesheet">
<script src="jquery.min.js"></script>
<script src="iconmenu.js">

</script>
<script>

ddiconmenu.docinit({ // initialize an Icon Menu
	menuid:'myiconmenu', //main menu ID
	easing:"easeInOutCirc",
	dur:500 //<--no comma after last setting
})


</script>

</head>

<body>
<!-- Main Icon Menu -->

<ul id="myiconmenu" class="iconmenu">

<li><a class="icon-twitter" href="Employee/index.php" target="_blank" rel="[title]" title="Login" style="background-image:url(images/login1.png);background-repeat:no-repeat"></a></li>

<li><a class="icon-twitter" href="https://www.facebook.com/" target="_blank" rel="[title]" title="Facebook" style="background-image:url(images/facebook.png);background-repeat:no-repeat"></a></li>

<li><a class="icon-twitter" href="https://twitter.com/login" target="_blank" rel="[title]" title="Twitter" style="background-image:url(images/Twitter.png);background-repeat:no-repeat"></a></li>

<li><a class="icon-twitter" href="https://plus.google.com/" target="_blank" rel="[title]" title="Google+" style="background-image:url(images/Google+.png);background-repeat:no-repeat"></a></li>

<li><a class="icon-twitter" href="https://www.youtube.com" target="_blank" rel="[title]" title="YouTube" style="background-image:url(images/YouTube.png);background-repeat:no-repeat"></a></li>
</ul>

<!- CSS Library sub menu -->

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>