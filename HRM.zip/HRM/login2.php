<?php
    //$con = mysql_connect("localhost","root","") or die("error: could not connect to server");	
	//mysql_select_db("hoarding_db",$con);
	
	$con=mysql_connect("localhost","root","") or die("Connection Error".mysql_error());
	mysql_select_db("hoarding_db",$con) or die("Database Error".mysql_error());
	
	$msg="";	

if(isset($_POST['btnlogin']))
{
	$admin_email_id=$_POST['admin_email_id'];
	$admin_password = $_POST['password'];
		
	if($admin_email_id!=''&& $admin_password!='')
	{
		$qry= mysql_query("select * from admin where admin_email_id='$admin_email_id' and password='$admin_password'");	
		$row= mysql_fetch_array($qry);
		$count=mysql_num_rows($qry);	
		if($count==1)
		{
				session_start();
				$_SESSION['admin_id'] = $row[0];
				$_SESSION['admin_name'] = $row[1];				
				header("location:admin.php");
		}
		else
		{
			$msg= "<div class='alert alert-info alert-login'>
						Invalid Admin email_id & password			
					</div>";
			
		}
		mysql_close($con);	
	}
}
?>
<!DOCTYPE html>
<html lang="en">
    
<head>
        <title>hoarding Admin</title><meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="css/maruti-login.css" />
		<script type="text/javascript" language="javascript">
function fun()
{
if(document.frm.admin_email_id.value=="")
{
	document.getElementById("admin_email_id").innerHTML="please fill the user name";
	document.frm.admin_email_id.focus();
	return false;
}
else
{
	document.getElementById("admin_email_id").innerHTML="";
}
if(document.frm.password.value=="")
{
	document.getElementById("password").innerHTML="please fill the password";
	document.frm.password.focus();
	return false;
}
else
{
	document.getElementById("password").innerHTML="";
}
return true;
}
</script>	
    </head>
    <body>
        <div id="logo">
            <img src="img/login-logo.png" alt="" />
        </div>
        <div id="loginbox">            
            <form id="loginform" class="form-vertical" action="" method="post">
				 <div class="control-group normal_text"><h3> hoarding Login</h3><center><h4>admin login</h4></center></div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-user"></i></span><input type="text" id="admin_email_id" name="admin_email_id" placeholder="admin_email_id" value="" />
						</div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="password" name="password" placeholder="password" value="" />
							
                        </div>
                    </div>
                </div>
				<?php
				
			echo"<center>$msg</center>"
			
			?>
                <div class="form-actions">
                    <span class="pull-left"><a href="#" class="flip-link btn btn-warning" id="to-recover">Lost password?</a></span>
                    <span class="pull-right"><input type="submit" class="btn btn-success" value="Login"  name="btnlogin" id="btnlogin"/></span>
                </div>
            </form>
            <form id="recoverform" action="#" class="form-vertical">
				<p class="normal_text">Enter your e-mail address below and we will send you instructions <br/><font color="#FF6633">how to recover a password.</font></p>
				
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-envelope"></i></span><input type="text" placeholder="E-mail address" />
                        </div>
                    </div>
               
                <div class="form-actions">
                    <span class="pull-left"><a href="#" class="flip-link btn btn-warning" id="to-login" onClick="return fun(this.form);">&laquo; Back to login</a></span>
                    <span class="pull-right"><input type="submit" class="btn btn-info" value="Recover" /></span>
                </div>
            </form>
        </div>
        
        <script src="js/jquery.min.js"></script>  
        <script src="js/maruti.login.js"></script> 
    </body>


</html>
