<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Usersite | Home</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/georgia.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.html"><span>C</span>yano<br />
          <small>New form of design</small></a></h1>
      </div>
      <div class="menu">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="services.html" class="active">Services</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
    <div class="headert_text_resize_bg">
      <div class="headert_text_resize"> <img src="images/img_simple.jpg" alt="" width="380" height="231" />
        <div class="textarea">
          <h2>Template License</h2>
          <p><span>Posted by Owner | Filed under templates, internet</span></p>
          <p>This is a free CSS website template by HotWebsiteTemplates.net. This work is distributed under the <a href="http://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution 3.0 License</a>, which means that you are free to use it for any personal or commercial purpose provided you credit me in the form of a link back to HotWebsiteTemplates.net. </p>
          <p> <a href="#">&raquo; Read More...</a></p>
        </div>
      </div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="body">
    <div class="body_resize">
      <div class="left">
        <h2>Services</h2>
        <p class="big bgline">Mauris ornare aliquam urna, accumsan bibendum eros auctor ac.</p>
        <p>Suspendisse adipiscing rhoncus massa, sit amet sollicitudin quam vulputate non. In non turpis nisl. Curabitur purus mi, pharetra vitae viverra et, mattis sit amet nunc.</p>
        <p>Quisque enim ipsum, convallis sit amet molestie in, placerat vel urna.Suspendisse adipiscing rhoncus massa, sit amet sollicitudin quam vulputate non. In non turpis nisl.</p>
        <p>Curabitur purus mi, pharetra vitae viverra et, mattis sit amet nunc. Quisque enim ipsum, convallis sit amet molestie in, placerat vel urna.Suspendisse adipiscing rhoncus massa, sit amet sollicitudin quam vulputate non. In non turpis nisl. Curabitur purus mi, pharetra vitae viverra et, mattis sit amet nunc. Quisque enim ipsum, convallis sit amet molestie in, placerat vel urna.</p>
        <p>Suspendisse adipiscing rhoncus massa, sit amet sollicitudin quam vulputate non. In non turpis nisl. Curabitur purus mi, pharetra vitae viverra et, mattis sit amet nunc. Quisque enim ipsum, convallis sit amet molestie in, placerat vel urna.</p>
      </div>
      <div class="right_resize">
        <div class="right">
          <h2><span>What</span> They Say</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
          <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui off icia deserunt mollit anim id estlaborum.</p>
          <img src="images/banner_5.jpg" alt="" width="68" height="68" />
          <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
        </div>
        <div class="right">
          <h2>Search</h2>
          <div class="search">
            <form id="form1" name="form1" method="post" action="#">
              <span>
              <input name="q" type="text" class="keywords" id="textfield" maxlength="50" value="Search..." />
              </span>
            </form>
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="FBG">
    <div class="FBG_resize">
      <div class="blok">
        <h2>About</h2>
        <img src="images/fbg_1.jpg" alt="" width="68" height="68" />
        <p><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</span> Donec libero. Suspendisse bibendum. Cras id urna. Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu turpis varius lorem, eu posuere nunc justo tempus leo. Donec mattis, purus nec placerat bibendum, dui pede condimentum odio, ac blandit ante orci ut diam.</p>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing urna.</p>
        <p> <a href="#">Learn more...</a><br />
        </p>
      </div>
      <div class="blok">
        <h2><span>Lorem</span> Ipsum</h2>
        <p><strong>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</strong> Donec libero. Suspendisse bibendum. Cras id urna. Morbi tincidunt, orci ac convallis aliquam, lectus turpis varius lorem, eu posuere nunc justo tempus leo. <br />
          Donec mattis, purus nec placerat bibendum, dui pede condimentum odio, ac blandit ante orci ut diam.</p>
        <ul>
          <li><a href="#">consequat molestie</a></li>
          <li><a href="#">sem justo</a></li>
          <li><a href="#">semper</a></li>
          <li><a href="#">magna sed purus</a></li>
        </ul>
      </div>
      <div class="blok">
        <h2><span>Image</span> Gallery</h2>
        <img src="images/banner_1.jpg" alt="" width="68" height="68" /><img src="images/banner_2.jpg" alt="" width="68" height="68" /><img src="images/banner_3.jpg" alt="" width="68" height="68" /><img src="images/banner_4.jpg" alt="" width="68" height="68" /><img src="images/banner_5.jpg" alt="" width="68" height="68" /><img src="images/banner_6.jpg" alt="" width="68" height="68" />
        <div class="clr"></div>
        <h2>Lorem ipsum </h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec libero. Suspendisse bibendum. </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="clr"></div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">MyWebSite</a>.</p>
      <p class="rf">Layout by Hot <a href="http://www.hotwebsitetemplates.net/">Website Templates</a></p>
      <div class="clr"></div>
    </div>
    <div class="clr"></div>
  </div>
</div>
</body>
</html>
