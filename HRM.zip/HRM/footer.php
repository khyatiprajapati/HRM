  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#"></a>SoftMaxSolutions</p>
      <p class="rf">Design By <a href="http://www.softmaxsolutions.com/">SoftMaxSolutions</a></p>
      <div class="clr"></div>
    </div>
    <div class="clr"></div>
  </div>