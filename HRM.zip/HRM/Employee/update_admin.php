<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM admin WHERE Admin_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("admin","$id","Admin_ID","");
	header("location:display_admin.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Admin Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Admin Detail<a href="display_admin.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Admin Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>	
										<div class="control-group">
										<label class="control-label">Admin Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtAdmin_Name" name="txtAdmin_Name" value="<?php echo $row['Admin_Name'];?>">

											<div id="txtAdmin_Name1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Gender</label>
										<div class="controls">
											<select name="cmbGender" id="cmbGender" value="<?php echo $row['Gender'];?>">
												<option value="select">Select</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
											</select>
											<div id="cmbGender1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Date OF Birth</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtDate_Of_Birth" id="txtDate_Of_Birth" value="<?php echo $row['Date_Of_Birth'];?>">
											<div id="txtDate_Of_Birth1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input class="input-large" type="text" name="txtEmail_ID" id="txtEmail_ID" value="<?php echo $row['Email_ID'];?>">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input502">Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" name="pwdPassword" id="pwdPassword" value="<?php echo $row['Password'];?>">
											<div id="pwdPassword1"></div>
										</div>
									</div>
										<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>