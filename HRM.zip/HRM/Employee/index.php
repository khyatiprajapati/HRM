<?php
    //$con = mysql_connect("localhost","root","") or die("error: could not connect to server");	
	//mysql_select_db("hrm_db",$con);
	
	$con=mysql_connect("localhost","root","") or die("Connection Error".mysql_error());
	mysql_select_db("hrm_db",$con) or die("Database Error".mysql_error());
	
	$msg="";	

if(isset($_POST['btnlogin']))
{
	$Email_Id=$_POST['Email_ID'];
	$Password= $_POST['Password'];
		
	if($Email_Id!=''&& $Password!='')
	{
		$qry= mysql_query("select * from emp_personaldetail where Email_ID='$Email_Id' and Password='$Password'");	
		$row= mysql_fetch_array($qry);
		$count=mysql_num_rows($qry);	
		if($count==1)
		{		
				session_start();
				$_SESSION['Emp_ID'] = $row[0];
				$_SESSION['First_Name'] = $row[1];
				$_SESSION['start_date'] = date("Y/m/d H:i:s");					
				header("location:update_emp_personaldetail.php");
		}
		else
		{
			$msg= "<div class='alert alert-info alert-login'>
						Invalid Employee Email_ID & Password			
					</div>";
			
		}
		mysql_close($con);	
	}
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Human Resource Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- styles -->
<link href="css/bootstrap.css" rel="stylesheet"> 
<link href="css/jquery-ui-1.8.16.custom.css" rel="stylesheet">
<link href="css/jquery.jqplot.css" rel="stylesheet">
<link href="css/prettify.css" rel="stylesheet">
<link href="css/elfinder.min.css" rel="stylesheet">
<link href="css/elfinder.theme.css" rel="stylesheet">
<link href="css/fullcalendar.css" rel="stylesheet">
<link href="js/plupupload/jquery.plupload.queue/css/jquery.plupload.queue.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="css/icons-sprite.css" rel="stylesheet">
<link id="themes" href="css/themes.css" rel="stylesheet">
</head>
<body>
<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container-fluid">
			<div class="branding">
				<div class="logo">
					<a href="index.html"><a href="" style="font-size:16px;color:#FFFFFF;font-weight:bold">Human Resource Management</a> </a>
				</div>
			</div>
			<ul class="nav pull-right">
				<li><a href="attendence.php"><i class="icon-share-alt icon-white"></i>Attendence</a></li>
			</ul>
		</div>
	</div>
</div>
<form method="post">
<div class="login-container">
	<div class="well-login">
		<div class="control-group">
			<div class="controls">
				
				<div>
					<input type="text" placeholder="Username or Email" name="Email_ID" id="Email_ID" class="login-input user-name">
				</div>
			</div>
		</div>
		<div class="control-group">
			<div class="controls">
				<div>
					<input type="password" placeholder="Password"  name="Password" id="Password" class="login-input user-pass">
				</div>
			</div>
		</div>
		<div class="clearfix">
			<input class="btn btn-inverse login-btn" type="submit" name="btnlogin" id="btnlogin" value="Login">
		</div>
		<div class="remember-me">
			<a href="forgetpassword.php">Forget Password...!</a>
		</div>
	</div>
</div>
</form>
<script src="js/jquery.js"></script>
<script src="js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/prettify.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/accordion.jquery.js"></script>
<script src="js/smart-wizard.jquery.js"></script>
<script src="js/vaidation.jquery.js"></script>
<script src="js/jquery-dynamic-form.js"></script>
<script src="js/fullcalendar.js"></script>
<script src="js/raty.jquery.js"></script>
<script src="js/jquery.noty.js"></script>
<script src="js/jquery.cleditor.min.js"></script>
<script src="js/data-table.jquery.js"></script>
<script src="js/TableTools.min.js"></script>
<script src="js/ColVis.min.js"></script>
<script src="js/plupload.full.js"></script>
<script src="js/elfinder/elfinder.min.js"></script>
<script src="js/chosen.jquery.js"></script>
<script src="js/uniform.jquery.js"></script>
<script src="js/jquery.tagsinput.js"></script>
<script src="js/jquery.colorbox-min.js"></script>
<script src="js/check-all.jquery.js"></script>
<script src="js/inputmask.jquery.js"></script>
<script src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>
<script src="js/plupupload/jquery.plupload.queue/jquery.plupload.queue.js"></script>
<script src="js/excanvas.min.js"></script>
<script src="js/jquery.jqplot.min.js"></script>
<script src="js/chart/jqplot.highlighter.min.js"></script>
<script src="js/chart/jqplot.cursor.min.js"></script>
<script src="js/chart/jqplot.dateAxisRenderer.min.js"></script>
<script src="js/custom-script.js"></script>
<script src="js/respond.min.js"></script>
<script src="js/ios-orientationchange-fix.js"></script>
</body>
</html>
