<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM advance_salary WHERE Advance_ID=".$id;
	exenonQuery($q);
	header("location:display_advance_salary.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Upgrade Salary</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Upgrade Salary Information<a href="advance_salary.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Salary</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT a1.Advance_ID,a1.Emp_ID,e1.First_Name,a1.AdvanceApply_Date,a1.Amount,a1.Reason,a1.Status,a1.Approve_Date from advance_salary as a1,emp_personaldetail e1 where e1.Emp_ID=a1.Emp_ID ORDER BY a1.Advance_ID";
		
		
		$arr=array("Emp_ID","First Name","AdvanceApply_Date","Amount","Reason","Status","Approve_Date");
		echo displayData($arr,$q,"update_advance_salary.php","display_advance_salary.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>