<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM salary_component WHERE Salary_Component_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("salary_component","$id","Salary_Component_ID","");
	header("location:display_salary_component.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM |Salary Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Salary Detail <a href="display_salary_component.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Salary Detail </a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
											<?php $emp="SELECT Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBoxUpdate($emp,$row['Emp_ID']);?>
											</select>
											<div id="cmbEmp_ID"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Salary Component Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtSalary_Component_Name" name="txtSalary_Component_Name" value="<?php echo $row['Salary_Component_Name'];?>">
											<div id="txt1Salary_Component_Name"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">JobTitle_ID</label>
										<div class="controls">
											<?php $job="SELECT JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID" value="<?php echo $row['JobTitle_ID'];?>">
												<?php echo FillComboBox($job);?>
											</select>
											<div id="cmbJobTitle_ID"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">PayFrequency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPayFrequency" name="txtPayFrequency" value="<?php echo $row['PayFrequency'];?>">
											<div id="txtPayFrequency1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Currency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCurrency" name="txtCurrency" value="<?php echo $row['Currency'];?>">
											<div id="txt1Currency"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Amount</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtAmount" name="txtAmount" value="<?php echo $row['Amount'];?>">
											<div id="txtAmount1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Pay Method</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPay_Method" name="txtPay_Method" value="<?php echo $row['Pay_Method'];?>">
											<div id="txtPay_Method1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Bank Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtBank_Name" name="txtBank_Name" value="<?php echo $row['Bank_Name'];?>">
											<div id="txtBank_Name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Account Number</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtAccount_Number" name="txtAccount_Number" value="<?php echo $row['Account_Number'];?>">
											<div id="txtAccount_Number1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">Comments</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtComments" id="txtComments" value="<?php echo $row['Comments'];?>"></textarea>
											<div id="txtComments1"></div>
										</div>
									</div>
			
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>