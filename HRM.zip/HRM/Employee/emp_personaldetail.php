<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_personaldetail","Emp_ID",$emp_image);
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Employee Personal Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Personal Detail <a href="display_emp_personaldetail.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Employee Personal Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">First Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFirst_Name" name="txtFirst_Name">
											<div id="txtFirst_Name1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Middle Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMiddle_Name" name="txtMiddle_Name">
											<div id="txtMiddle_Name1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Last Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtLast_Name" name="txtLast_Name">
											<div id="txtLast_Name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Select Image</label>
										<div class="controls">
											<input class="input-file" type="file" name="fileimage_name" id="fileimage_name">
											<div id="fileimage_name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">DrivingLicence No.</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtDrivingLicence_No" name="txtDrivingLicence_No">
											<div id="txtDrivingLicence_No1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">DrivingLicence Expirydate</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtDrivingLicence_Expirydate" id="txtDrivingLicence_Expirydate">
											<div id="txtDrivingLicence_Expirydate1"></div>
										</div>
									</div>	
									
										
										<div class="control-group">
										<label class="control-label">Gender</label>
										<div class="controls">
											<select name="cmbgender" id="cmbgender">
												<option value="select">Select</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
											</select>
											<div id="cmbgender1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Mertial Status</label>
										<div class="controls">
											<select name="cmbMertial_Status" id="cmbMertial_Status">
												<option value="select">Select</option>
												<option value="Married">Married</option>
												<option value="Unmarried">Unmarried</option>
											</select>
											<div id="cmbMertial_Status"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">Nationality</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtNationality" name="txtNationality">
											<div id="txtNationality1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">Date Of Birth</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtDate_of_birth" id="txtDate_of_birth">
											<div id="txtDate_of_birth1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input class="input-large" type="text" name="txtEmail_ID" id="txtEmail_ID">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>	
									<div class="control-group">
										<label class="control-label">Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" name="pwdpassword" id="pwdpassword">
											<div id="pwdpassword1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>