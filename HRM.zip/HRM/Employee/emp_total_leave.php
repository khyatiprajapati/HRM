<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_total_leave","EmpTotalLeave_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee total leave Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee total leave Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
							<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
	
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbEmp_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Emp_Leave_ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmp_Leave_ID" name="txtEmp_Leave_ID">
											<div id="txtEmp_Leave_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Total_Leave_Days</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtTotal_Leave_Days" name="txtTotal_Leave_Days">
											<div id="txtTotal_Leave_Days1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Reason</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtReason" id="txtReason"></textarea>
											<div id="txtReason1"></div>
										</div>
									</div>
								
										<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>