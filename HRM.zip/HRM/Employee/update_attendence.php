<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM attendence WHERE Atten_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("attendence","$id","Atten_ID","");
	header("location:display_attendence.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM|Attendence Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Attendence Information<a href="display_attendence.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Attendence Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
											<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID" value="<?php echo $row['Emp_ID'];?>">
												<?php echo FillComboBoxUpdate($emp,$row['Emp_ID']);?>
											</select>
											<div id="cmbEmp_ID1"></div>
										</div>
									</div>
								
									<div class="control-group">
										<label class="control-label" for="input501">User Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtUser_Name" name="txtUser_Name" value="<?php echo $row['User_Name'];?>">
											<div id="txtUser_Name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input502">Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" name="pwdpassword" id="pwdpassword"value="<?php echo $row['Password'];?>">
											<div id="pwdpassword1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Attendence Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtAtten_Date" id="txtAtten_Date" value="<?php echo $row['Atten_Date'];?>">
											<div id="txtAtten_Date1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>