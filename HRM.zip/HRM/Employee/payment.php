<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("payment","Payment_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Payment Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Payment Information<a href="display_payment.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Payment Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											 <?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbEmp_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Salary Month</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtSalary_Month" name="txtSalary_Month">
											<div id="txtSalary_Month1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">Pay Year</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPay_Year" name="txtPay_Year">
											<div id="txtPay_Year1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Payment Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtPayment_Date" id="txtPayment_Date">
											<div id="txtPayment_Date1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
									<label class="control-label" for="input501">Basic Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtBasic_Salary" name="txtBasic_Salary">
											<div id="txtBasic_Salary1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">HRA</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtHRA" name="txtHRA">
											<div id="txtHRA1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">DA</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtDA" name="txtDA">
											<div id="txtDA1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">TA</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtTA" name="txtTA">
											<div id="txtTA1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">PF</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPF" name="txtPF">
											<div id="txtPF1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">Gross Allowanced</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtGross_Allowanced" name="txtGross_Allowanced">
											<div id="txtGross_Allowanced1"></div>
										</div>
									</div>
									
									<div class="control-group">
									<label class="control-label" for="input501">Gross Deducted</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtGross_Deducted" name="txtGross_Deducted">
											<div id="txtGross_Deducted1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">Advance</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtAdvance" name="txtAdvance">
											<div id="txtAdvance1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">Net Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtNet_Salary" name="txtNet_Salary">
											<div id="txtNet_Salary1"></div>
										</div>
									</div>
									<div class="control-group">
									<label class="control-label" for="input501">Pay Method</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPay_Method" name="txtPay_Method">
											<div id="txtPay_Method1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>