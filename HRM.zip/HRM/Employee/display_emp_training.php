<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_training WHERE Emp_Training_ID=".$id;
	exenonQuery($q);
	header("location:display_emp_training.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee Training Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Training Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT e1.Emp_Training_ID,e1.Emp_ID,e.First_Name,e1.JobTitle_ID,e1.Training_ID from emp_training as e1,emp_personaldetail as e where e.Emp_ID=e1.Emp_ID ORDER BY e1.Emp_Training_ID";
		$arr=array("Emp_ID","First Name","JobTitle_ID","Training_ID");
		echo displayData($arr,$q,"update_emp_training.php","display_emp_training.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>