<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_dependate WHERE Emp_Dependent_ID=".$id;
	exenonQuery($q);
	header("location:display_emp_dependate.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Department Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Department Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT e1.Emp_Dependent_ID,e1.Emp_ID,e.First_Name,e1.Name,e1.Relationship from emp_dependate as e1,emp_personaldetail as e where e.Emp_ID=e1.Emp_ID ORDER BY e1.Emp_Dependent_ID";
		
		
		$arr=array("Emp_ID","First Name","Name","Relationship");
		echo displayData($arr,$q,"update_emp_dependate.php","display_emp_dependate.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>