<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM payment WHERE Payment_ID=".$id;
	exenonQuery($q);
	header("location:display_payment.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Employee Payment Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Payment Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT p.Payment_ID,e.First_Name,p.Salary_Month,p.Pay_Year,p.Payment_Date,p.Basic_Salary,p.Gross_Allowanced,p.Gross_Deducted,p.Advance,p.Net_Salary,p.Pay_Method from payment as p,emp_personaldetail as e where p.Emp_ID=e.Emp_ID ORDER BY p.Payment_ID";
		$arr=array("First Name","Salary_Month","Pay_Year","Payment_Date","Basic_Salary","Gross_Allowanced","Gross_Deducted","Advance","Net_Salary","Pay_Method");
		echo displayData($arr,$q,"update_payment.php","display_payment.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>