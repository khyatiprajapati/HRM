<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_personaldetail WHERE Emp_id=".$id;
	exenonQuery($q);
	header("location:display_emp_personaldetail.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Employeee Personal Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employeee Personal Detail<a href="emp_personaldetail.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add Employee Personal Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT Emp_ID,First_Name,image_name,Gender,Mertial_Status,Nationality,Date_of_birth,Email_ID from emp_personaldetail";
		
		$arr=array("First_Name","Image_Name","Gender","Mertial_Status","Nationality","Date_of_birth","Email_ID");
		echo displayData($arr,$q,"update_emp_personaldetail.php","display_emp_personaldetail.php",$emp_image);
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>