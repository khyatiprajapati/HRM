<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM education WHERE Level_ID=".$id;
	exenonQuery($q);
	header("location:display_education.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Education Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Education Information<a href="education.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Education</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="select Level_ID,Level_Name from education";
		$arr=array("Level_Name");
		echo displayData($arr,$q,"update_education.php","display_education.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>