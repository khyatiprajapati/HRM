<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";

if(isset($_GET['id']))

{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM leave_assign WHERE AssignLeave_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("leave_assign","$id","AssignLeave_ID","");
	header("location:display_leave_assign.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee Leave Assign</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Leave Assign Information<a href="display_leave_assign.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Employee Leave Assign</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmp_Name" name="txtEmp_Name" value="<?php echo $row['Emp_Name'];?>">
											<div id="txtEmp_name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Leave Type</label>
										<div class="controls">
											<select name="cmbLeave_Type" id="cmbLeave_Type">
												<option value="select">Select</option>
												<option value="Vacation">Vacation</option>
												<option value="Maternity">Maternity</option>
											</select>
											<div id="cmbLeave_Type1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">From Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtFrom_Date" id="txtFrom_Date" value="<?php echo $row['From_Date'];?>">
											<div id="txtFrom_Date1"></div>
										</div>
									</div>
									
									
									
									<div class="control-group">
										<label class="control-label">To Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtTo_Date" id="txtTo_Date" value="<?php echo $row['To_Date'];?>">
											<div id="txtTo_Date1"></div>
										</div>
									</div>
									
									
										<div class="control-group">
										<label class="control-label">Description</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtDescription" id="txtDescription" value="<?php echo $row['Description'];?>">
											</textarea>
											<div id="txtDescription1"></div>
										</div>
									</div>
			
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>