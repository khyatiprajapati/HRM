<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM holidays WHERE Holiday_ID=".$id;
	exenonQuery($q);
	header("location:display_holidays.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Holidays Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Holidays Detail</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT Holiday_ID,Name,Holiday_Date,Period from holidays ";
		$arr=array("Name","Holiday_Date","period");
		echo displayData($arr,$q,"update_holidays.php","display_holidays.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>