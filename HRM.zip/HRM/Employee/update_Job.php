<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM  job WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	$id_c = $row['Job_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData(" job","$id_c","Job_ID","");
	header("location:update_job.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM |  Job Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> Job Detail </h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									
									<div class="control-group">
										<label class="control-label">Job Title </label>
										<div class="controls">
										<?php $job="select JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBoxUpdate($job,$row1['JobTitle_ID']);?>
											</select>
											<div id="txtJobTitle_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Job Specification</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtJob_Specification" name="txtJob_Specification" value="<?php echo $row1['Job_Specification'];?>">
											<div id="txtJob_Specification1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Employment Status</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmployment_Status" name="txtEmployment_Status" value="<?php echo $row1['Employment_Status'];?>">
											<div id="txtEmployment_Status1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Job Category</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtJob_Category" name="txtJob_Category" value="<?php echo $row1['Job_Category'];?>">
											<div id="txtJob_Category1"></div>
										</div>
									</div>
									
									
									
									<div class="control-group">
										<label class="control-label">Joined Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtJoined_Date" id="txtJoined_Date" value="<?php echo $row1['Joined_Date'];?>">
											<div id="txtJoined_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Location</label>
										<div class="controls">
											<input class="input-file" type="text" name="txtLocation" id="txtLocation" value="<?php echo $row1['Location'];?>">
											<div id="txtLocation1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Start Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtStart_Date" id="txtStart_Date" value="<?php echo $row1['Start_Date'];?>">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">End Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtEnd_Date" id="txtEnd_Date" value="<?php echo $row1['End_Date'];?>">
											<div id="txtEnd_Date1"></div>
										</div>
									</div>
									
									
											
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>