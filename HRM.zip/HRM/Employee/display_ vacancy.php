<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM Vacancy WHERE Vacancy_ID=".$id;
	exenonQuery($q);
	header("location:display_Vacancy.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Vacancy Detail </title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Vacancy Detail <a href="Vacancy.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add Vacancy Detail </a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT v.Vacancy_ID,v.JobTitle_ID,j.Job_Title,v.Vacancy,v.Hiring_Manager,v.Status from Vacancy as v,jobtitle as j where v.JobTitle_ID=j.JobTitle_ID ORDER BY v.Vacancy_ID";
		$arr=array("Vacancy_ID","JobTitle_ID","Job Title","Vacancy","Hiring_Manager","Status");
		echo displayData($arr,$q,"update_vacancy.php","display_vacancy.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>