<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM company_info WHERE Company_ID=".$id;
	exenonQuery($q);
	header("location:display_company_info.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Company Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Company Information<a href="company_info.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Company Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		
		$q="SELECT c.Company_ID,c.Company_Name,c.Number_of_employee,c1.City_Name,c2.Country_Name,c.Phone,c.Email_ID FROM company_info as c,city as c1, country as c2 where c.City_ID=c1.City_ID AND c2.Country_ID=c.Country_ID order by c.Company_ID";
		$arr=array("Company Name","Number_of_employee","City","Country","Phone","Email ID");
		echo displayData($arr,$q,"update_company_info.php","display_company_info.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>