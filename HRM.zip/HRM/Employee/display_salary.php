<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM salary WHERE Salary_ID=".$id;
	exenonQuery($q);
	header("location:display_salary.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Salary Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Salary Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="select s.Salary_ID,s.JobTitle_ID,j.Job_Title,s.MinSalary,s.MaxSalary,s.PayFrequency from salary as s,jobtitle as j where s.JobTitle_ID=j.JobTitle_ID AND j.JobTitle_ID=s.JobTitle_ID ORDER BY s.JobTitle_ID" ;
		$arr=array("Job Title","MinSalary","MaxSalary","PayFrequency");
		echo displayData($arr,$q,"update_salary.php","display_salary.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>