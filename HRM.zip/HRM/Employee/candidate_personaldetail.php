<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("candidate_personaldetail","Candidate_Personaldetail_ID",$candidate);
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM |Candidate Personal Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Candidate Personal Detail<a href="display_candidate_personaldetail.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Candidate Personal Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">First Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFirst_Name" name="txtFirst_Name">
											<div id="txtFirst_Name1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label" for="input501">Middle Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMiddle_Name" name="txtMiddle_Name">
											<div id="txtMiddle_Name1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label" for="input501">Last Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtLast_Name" name="txtLast_Name">
											<div id="txtLast_Name1"></div>
										</div>
									</div>

									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmail_ID" name="txtEmail_ID">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Contact No</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtContact_No" name="txtContact_No">
											<div id="txtContact_No1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">job vacancy</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtjob_vacancy" name="txtjob_vacancy">
											<div id="txtjob_vacancy1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Resume Title</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtResume" name="txtResume">
											<div id="fileResume1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Updfile name</label>
										<div class="controls">
											<input class="input-file" type="file" name="pdffile_name" id="pdffile_name">
											<div id="pdffile_name1"></div>
										</div>
									</div>
										
									<div class="control-group">
										<label class="control-label" for="input502">Keyword</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtKeyword" name="txtKeyword"/>
											<div id="txtKeyword1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtComment" id="txtComment"></textarea>
											<div id="txtComment1"></div>
										</div>
									</div>
			
									<div class="control-group">
										<label class="control-label">Date of Application</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtDate_of_Application" id="txtDate_of_Application">
											<div id="txtDate_of_Application1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>