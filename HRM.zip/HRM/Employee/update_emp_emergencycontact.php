<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_emergencycontact WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	$id_c=$row['Emp_EmergencyContact_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_emergencycontact","$id_c","Emp_EmergencyContact_ID","");
	header("location:update_emp_emergencycontact.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Employee Emergency Contact Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Emergency Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									
									<div class="control-group">
										<label class="control-label">Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtName" name="txtName" value="<?php echo $row1['Name'];?>">
											<div id="txtName1"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">Employee Dependent ID</label>
										<div class="controls">
											 <?php $emp="select Emp_Dependent_ID,Emp_ID,Name,Relationship from emp_dependate";?>
											<select name="cmbEmp_Dependent_ID" id="cmbEmp_Dependent_ID" value="<?php echo $row1['Emp_Dependent_ID'];?>">
												<?php echo FillComboBoxUpdate($emp,$row1['Emp_Dependent_ID']);?>
											</select>
										
											<div id="cmbEmp_Dependent_ID1"></div>
									  </div>
								</div>		
									
									<div class="control-group">
										<label class="control-label">Home_Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtHome_Telephone" name="txtHome_Telephone" value="<?php echo $row1['Home_Telephone'];?>">
											<div id="txtHome_Telephone1"></div>
										</div>
									</div>		
									<div class="control-group">
										<label class="control-label">Mobile</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMobile" name="txtMobile" value="<?php echo $row1['Mobile'];?>">
											<div id="txtMobile1"></div>
										</div>
									</div>				
									<div class="control-group">
										<label class="control-label">Work_Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtWork_Telephone" name="txtWork_Telephone" value="<?php echo $row1['Work_Telephone'];?>">
											<div id="txtHome_Telephone1"></div>
										</div>
									</div>				
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>