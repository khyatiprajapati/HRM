<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM punch_in WHERE PunchIn_ID=".$id;
	exenonQuery($q);
	header("location:display_punch_in.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM|Punch In Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Punch In Detail<a href="punch_in.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Punch In Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT p.PunchIn_ID,p.Emp_ID,e.First_Name,p.PunchIn_Date,p.PunchIn_Time,p.PunchIn_Note from punch_in as p,emp_personaldetail as e where p.Emp_ID=e.Emp_ID ORDER BY p.PunchIn_ID  ";
		$arr=array("Emp_ID","First Name","PunchIn_Date","PunchIn_Time","PunchIn_Note");
		echo displayData($arr,$q,"update_punch_in.php","display_punch_in.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>