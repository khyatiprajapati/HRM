<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("leave_period","LeavePeriod_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Add Leave period</title>
<script src="validation.js" language="javascript"></script>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> Leave period Information <a href="display_leave_period.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display LEAVE PERIOD INFORAMTION</a></h5>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>								
                                	<div class="control-group">
										<label class="control-label">Start Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtStart_Date" id="txtStart_Date">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">End Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtEnd_Date" id="txtEnd_Date">
											<div id="txtEnd_Date1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>