<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM vacancy WHERE Vacancy_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("vacancy","$id","Vacancy_ID","");
	header("location:display_vacancy.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Vacancy Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Vacancy Detail<a href="display_vacancy.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Job Vacancy Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">JobTitle ID</label>
										<div class="controls">
											<?php $job="SELECT JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBoxUpdate($job,$row['JobTitle_ID']);?>
											</select>
											<div id="txtJobTitle_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Vacancy</label>
										<div class="controls">
										<select name="cmbVacancy" id="cmbVacancy"  value="<?php echo $row['Vacancy'];?>">
											<option value="Select">Select</option>
											<option value="HR Manager">HR Manager</option>
											<option value="Engineer">Engineer</option>
											<option value="Manager IT">Manager IT</option>
											<option value="Sales Manager">Sales Manager</option>
											<option value="Software Engineer">Software Engineer</option>
										</select>
										<div id="cmbVacancy1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Hiring Manager</label>
										<div class="controls">
										<select name="cmbHiring_Manager" id="cmbHiring_Manager" value="<?php echo $row['Hiring_Manager'];?>">
												<option value="Select">Select</option>
												<option value="Monkia Mathur">Monkia Mathur</option>
												<option value="Jennifer Smith">Jennifer Smith</option>
												<option value="Anthony Milan Nolan">Anthony Milan Nolan</option>
												<option value="Amadi Aswad">Amadi Aswad</option>
												<option value="Robert Craig">Robert Craig</option>
										</select>
										<div id="txtHiring_Manager1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Status</label>
										<div class="controls">
										<select name="cmbStatus" id="cmbStatus" value="<?php echo $row['Status'];?>">
											<option value="Select">Select</option>
											<option value="Closed">Closed</option>
											<option value="New">New</option>
											<option value="Published">Published</option>
											<option value="UnPublished">UnPublished</option>
										</select>
										<div id="cmbStatus1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>