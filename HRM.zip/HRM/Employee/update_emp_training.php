<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_training WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	$id_c=$row['Emp_Training_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_training","$id_c","Emp_Training_ID","");
	header("location:update_emp_training.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee Training Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Training Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									
									<div class="control-group">
										<label class="control-label">JobTitle ID</label>
										<div class="controls">
									<?php $job="select JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBoxUpdate($job,$row1['JobTitle_ID']);?>
											
											</select>
											<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
									
											<div class="control-group">
										<label class="control-label">Training ID</label>
										<div class="controls">
											<?php $training="select Training_ID,Training_Name,To_Date,From_Date,Place,Description from training";?>
											<select name="cmbTraining_ID" id="cmbTraining_ID">
												<?php echo FillComboBoxUpdate($training,$row1['Training_ID']);?>
									
											</select>
												<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
									
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>