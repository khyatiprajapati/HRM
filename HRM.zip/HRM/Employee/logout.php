<?php
include("include/connection.php");
$cn=getCon();
session_start();
//session_destroy();
$_SESSION['username']="";
$_SESSION['end_date']=date("Y/m/d H:i:s");
$q1="INSERT INTO log VALUES(null,".$_SESSION['Emp_ID'].",'".$_SERVER['REMOTE_ADDR']."','EMPLOYEE','".$_SESSION['start_date']."','".$_SESSION['end_date']."')";

mysql_query($q1,$cn)or die(mysql_error());

//echo $q1;
//exit;
header('location:index.php');
?>
