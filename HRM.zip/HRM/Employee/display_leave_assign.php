<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM leave_assign WHERE AssignLeave_ID=".$id;
	exenonQuery($q);
	header("location:display_leave_assign.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Employee Leave Assign Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Leave Assign Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT AssignLeave_ID,Emp_Name,Leave_Type,From_Date,To_Date,Description from leave_assign where  Emp_Name = '".$_SESSION['First_Name']."'";
		//echo $q ; exit;
		$arr=array("Emp_Name","Leave_Type","From_Date","To_Date","Description");
		echo displayData($arr,$q,"update_leave_assign.php","display_leave_assign.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>