<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{

	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_personaldetail WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_personaldetail","$id","Emp_ID",$empside_image);
	header("location:update_emp_personaldetail.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Employee Personal Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Personal Detail</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">First Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFirst_Name" name="txtFirst_Name" value="<?php echo $row['First_Name'];?>">
											<div id="txtFirst_Name1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Middle Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMiddle_Name" name="txtMiddle_Name" value="<?php echo $row['Middle_Name'];?>">
											<div id="txtMiddle_Name1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Last Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtLast_Name" name="txtLast_Name" value="<?php echo $row['Last_Name'];?>">
											<div id="ttxmobile_no1"></div>
										</div>
									</div>
										
										<div class="control-group">
										<label class="control-label">Select Image</label>
 										<div class="controls">
											<input class="input-file" type="file" name="fileimage_name" id="fileimage_name" value="<?php echo $row['image_name'];?>">
											<div id="fileimage_name1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">DrivingLicence No.</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtDrivingLicence_No" name="txtDrivingLicence_No" value="<?php echo $row['DrivingLicence_No'];?>">
											<div id="txtDrivingLicence_No1"></div>
										</div>
									</div>
									
									<div class="control-group">
									<label class="control-label">DrivingLicence Expirydate</label>
									<div class="controls">
										<div class="input-append">
											<input class="input-large" type="date" name="txtDrivingLicence_Expirydate" id="txtDrivingLicence_Expirydate" value="<?php echo $row['DrivingLicence_Expirydate'];?>">
											<div id="txtDrivingLicence_Expirydate1"></div>
										</div>
									</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Gender</label>
										<div class="controls">
										<?php $gen = $row['Gender'];?>
											<select name="cmbGender" id="cmbGender" >
												<option value="select">Select</option>
												<?php
												if($gen=='Male'){
												?>
													<option value="Male" selected >Male</option>
													<option value="Female">Female</option>												
												<?php
												}
												else{
												?>
												<option value="Male">Male</option>
												<option value="Female" selected >Female</option>
												<?php } ?>										
												</select>
											<div id="cmbGender1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Mertial Status</label>
										<div class="controls">
											<select name="cmbMertial_Status" id="cmbMertial_Status" >
												<?php $mer = $row['Mertial_Status'];?>
											
												
												<?php
												if($mer=='Married'){
												?>
													<option value="Married" selected="selected">Married</option>
												<option value="Unmarried">Unmarried</option>												
												<?php
												}
												else{
												?>
												<option value="Married">Married</option>
												<option value="Unmarried" selected="selected">Unmarried</option>
												<?php } ?>										
												

											</select>
											<div id="cmbMertial_Status"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label" for="input502">Nationality</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtNationality" name="txtNationality" value="<?php echo $row['Nationality'];?>"/>
											<div id="txtNationality1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Date Of Birth</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtDate_of_birth" id="txtDate_of_birth" value="<?php echo $row['Date_of_Birth'];?>">
											<div id="txtDate_of_birth1"></div>
										</div>
									</div>	
									
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input class="input-large" type="text" name="txtEmail_ID" id="txtEmail_ID" value="<?php echo $row['Email_ID'];?>">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input502">Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" name="pwdpassword" id="pwdpassword" value="<?php echo $row['Password'];?>">
											<div id="pwdpassword1"></div>
										</div>
									</div>
									
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Save changes">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>