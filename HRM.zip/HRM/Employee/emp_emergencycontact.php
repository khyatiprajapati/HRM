<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_emergencycontact","Emp_EmergencyContact_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>  HRM  | Employee Emergency Contact Information </title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Emergency Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
												<div id="cmbEmp_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
									<label class="control-label" for="input501">Name</label>
									<div class="controls">
											<input type="text" class="input-xlarge" id="txtName" name="txtName">
											<div id="txtName1"></div>
										</div>
									</div>
										
										<div class="control-group">
										<label class="control-label">Employee Dependent ID</label>
										<div class="controls">
										<?php $emp="select Emp_Dependent_ID,Emp_ID,Name,Relationship from emp_dependate";?>
											<select name="cmbEmp_Dependent_ID" id="cmbEmp_Dependent_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbEmp_Dependent_ID1"></div>
										</div>
									</div>
									
										
										<div class="control-group">
										<label class="control-label">Home Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtHome_Telephone" name="txtHome_Telephone">
											<div id="txtHome_Telephone1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Mobile</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMobile" name="txtMobile">
											<div id="txtMobile1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Work Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtWork_Telephone" name="txtWork_Telephone">
											<div id="txtWork_Telephone1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>