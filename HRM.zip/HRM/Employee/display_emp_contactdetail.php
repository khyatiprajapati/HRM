<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_contactdetail WHERE Emp_Contact_ID=".$id;
	exenonQuery($q);
	header("location:display_emp_contactdetail.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Contact Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT e.Emp_Contact_ID,e.Emp_ID,e1.First_Name,e.Address1,c.City_Name,c1.Country_Name,e.Home_Telephone,e.Moblie,e.Work_Telephone,e.Work_Email FROM emp_contactdetail as e,emp_personaldetail as e1,city as c, country as c1 where e.Emp_ID=e1.Emp_ID AND e.City_ID=c.City_ID AND e.Country_ID=c1.Country_ID ORDER BY e.Emp_Contact_ID";
		$arr=array("Emp_ID","First Name","Address1","City","Country","Home_Telephone","Moblie","Work_Telephone","Work_Email");
		echo displayData($arr,$q,"update_emp_contactdetail.php","display_emp_contactdetail.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
ss</html>