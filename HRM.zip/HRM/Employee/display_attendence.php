<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM attendence WHERE Atten_ID=".$id;
	exenonQuery($q);
	header("location:display_attendence.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Attendence</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Attendence Information<a href="attendence.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Attendence</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT a.Atten_ID,a.Emp_ID,e.First_Name,a.User_Name,a.Password,a.Atten_Date from attendence as a,emp_personaldetail e where e.Emp_ID=a.Emp_ID ORDER BY a.Atten_ID";
		
		$arr=array("Emp_ID","First Name","User_Name","Password","Atten_Date");
		echo displayData($arr,$q,"update_attendence.php","display_attendence.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>