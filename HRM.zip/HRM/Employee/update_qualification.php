<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM qualification WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	$id_c=$row['Qualification_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("qualification","$id_c","Qualification_ID","");
	header("location:update_qualification.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Qualification Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Qualification Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
										<?php $emp="select Emp_ID,First_Name from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBoxUpdate($emp,$row['Emp_ID']);?>
											</select>
											<div id="txtEmp_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Level</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtLevel" name="txtLevel" value="<?php echo $row1['Level'];?>">
											<div id="txtLevel1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Institute</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtInstitutel" name="txtInstitute" value="<?php echo $row1['Institute'];?>">
											<div id="txtInstitute1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Specialization</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtSpecialization" name="txtSpecialization" value="<?php echo $row1['Specialization'];?>">
											<div id="txtSpecialization1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Year</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtYear" name="txtYear" value="<?php echo $row1['Year'];?>">
											<div id="txtYear1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Score</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txxScore" name="txxScore" value="<?php echo $row1['Score'];?>">
											<div id="txxScore1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Start Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtStart_Date" id="txtStart_Date" value="<?php echo $row1['Start_Date'];?>">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">End Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtEnd_Date" id="txtEnd_Date" value="<?php echo $row1['End_Date'];?>">
											<div id="txtEnd_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Language</label>
										<div class="controls">
											<?php $lang="select Language_ID,Language_Name from language";?>
											<select  name="cmbLanguage" id="cmbLanguage">
												<?php echo FillComboBoxUpdate($lang,$row1['Language']);?>
											</select>
											<div id="ttxLanguage1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Fluency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFluency" name="txtFluency" value="<?php echo $row1['Fluency'];?>">
											<div id="txtFluency1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Competency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCompetency" name="txtCompetency" value="<?php echo $row1['competency'];?>">
											<div id="txtCompetency1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Language Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtLanguage_comment" id="txtLanguage_comment">
											<?php 
												echo $row1['Language_comment'];?>
											</textarea>
											<div id="txtLanguage_comment1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Skill</label>
										<div class="controls">
											<?php $emp="select Skill_ID,Skill_Name from skill";?>
											<select  name="cmbSkill" id="cmbSkill">
												<?php echo FillComboBoxUpdate($emp,$row1['Skill']);?>
											</select>
											<div id="ttxSkill1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Year Of Experience</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtYear_of_experience" name="txtYear_of_experience" value="<?php echo $row1['Year_of_experience'];?>">
											<div id="txtYear_of_experience1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Skill Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtSkill_comment" id="txtSkill_comment">
											<?php 
												echo $row1['Language_comment'];?>
											</textarea>
											<div id="txtSkill_comment1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Company</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCompany" name="txtCompany" value="<?php echo $row1['Company'];?>">
											<div id="txtCompany1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Job Title</label>
										<div class="controls">
											<?php $emp="select JobTitle_ID,Job_Title from jobtitle";?>
											<select  name="cmbJob_Title" id="cmbJob_Title">
											<?php echo FillComboBoxUpdate($emp,$row1['Job_Title']);?>
											</select>
											<div id="ttxJob_Title1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">From Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtFrom_Date" id="txtFrom_Date" value="<?php echo $row1['From_Date'];?>">
											<div id="txtFrom_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">To Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtTo_Date" id="txtTo_Date" value="<?php echo $row1['To_Date'];?>">
											<div id="txtTo_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Experience Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtExperience_Comment" id="txtExperience_Comment">
											<?php 
												echo $row1['Experience_Comment'];?>
											</textarea>
											<div id="txtExperience_Comment1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>