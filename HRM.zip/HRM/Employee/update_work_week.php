<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM work_week WHERE WorkWeek_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("work_week","$id","WorkWeek_ID","");
	header("location:display_work_week.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | WorkWeek Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>WorkWeek Detail<a href="display_work_week.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display WorkWeek Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Monday</label>
										<div class="controls">
											<select name="cmbMonday" id="cmbMonday" value="<?php echo $row['Monday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbMonday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Tuesday</label>
										<div class="controls">
											<select name="cmbTuesday" id="cmbTuesday"  value="<?php echo $row['Tuesday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbTuesday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Wednesday</label>
										<div class="controls">
											<select name="cmbWednesday" id="cmbWednesday"  value="<?php echo $row['wednesday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbWednesday1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Thursday</label>
										<div class="controls">
											<select name="cmbThursday" id="cmbThursday"  value="<?php echo $row['Thursday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbThursday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Friday	</label>
										<div class="controls">
											<select name="cmbFriday" id="cmbFriday"  value="<?php echo $row['Friday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbFriday1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Saturday</label>
										<div class="controls">
											<select name="cmbSaturday" id="cmbSaturday"  value="<?php echo $row['Saturday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbSaturday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Sunday</label>
										<div class="controls">
											<select name="cmbSunday" id="cmbSunday"  value="<?php echo $row['Sunday']?>">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbSunday1"></div>
										</div>
									</div>

									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>