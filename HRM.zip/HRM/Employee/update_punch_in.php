<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM punch_in WHERE PunchIn_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("punch_in","$id","PunchIn_ID","");
	header("location:display_punch_in.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Punch In Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Punch In Detail<a href="display_punch_in.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Punch In Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
								<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
										<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBoxUpdate($emp,$row['Emp_ID']);?>
											</select>
											<div id="txtEmp_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">PunchIn Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtPunchIn_Date" id="txtPunchIn_Date"  value="<?php echo $row['PunchIn_Date'];?>">
											<div id="txtPunchIn_Date1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">PunchIn Time</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPunchIn_Time" name="txtPunchIn_Time" value="<?php echo $row['PunchIn_Time'];?>">
											<div id="txtPunchIn_Time1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">PunchIn Note</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtPunchIn_Note" id="txtPunchIn_Note" value="<?php echo $row['PunchIn_Note'];?>">
											</textarea>
											<div id="txtPunchIn_Note1"></div>
										</div>
									</div>	
									
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>