<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("work_week","WorkWeek_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | WorkWeek Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> WorkWeek Detail<a href="display_work_week.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display WorkWeek Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
										<div class="control-group">
										<label class="control-label">Monday</label>
										<div class="controls">
											<select name="cmbMonday" id="cmbMonday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbMonday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Tuesday</label>
										<div class="controls">
											<select name="cmbTuesday" id="cmbTuesday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbTuesday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Wednesday</label>
										<div class="controls">
											<select name="cmbWednesday" id="cmbWednesday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbWednesday1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Thursday</label>
										<div class="controls">
											<select name="cmbThursday" id="cmbThursday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbThursday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Friday	</label>
										<div class="controls">
											<select name="cmbFriday" id="cmbFriday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbFriday1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label">Saturday</label>
										<div class="controls">
											<select name="cmbSaturday" id="cmbSaturday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbSaturday1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Sunday</label>
										<div class="controls">
											<select name="cmbSunday" id="cmbSunday">
												<option value="select">Select</option>
												<option value="Fullday">Fullday</option>	
												<option value="Non-Workingday">Non-Workingday</option>
												<option value="Halfday">Halfday</option>
											</select>
											<div id="cmbSunday1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>