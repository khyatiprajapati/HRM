<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM leave_type WHERE LeaveType_ID=".$id;
	exenonQuery($q);
	header("location:display_leave_type.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Leave Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Leave Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="select LeaveType_ID,Name from leave_type ";
		$arr=array("Name");
		echo displayData($arr,$q,"update_leave_type.php","display_leave_type.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>