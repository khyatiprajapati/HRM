<?php
session_start();
if(isset($_SESSION['Emp_ID']))
{
	$emp_id=$_SESSION['Emp_ID'];
	$first_name=$_SESSION['First_Name'];
}
else
{
	header("location:index.php");
}
	
?>
