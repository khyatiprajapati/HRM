<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM qualification WHERE Qualification_id=".$id;
	exenonQuery($q);
	header("location:display_qualification.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Qualification Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Qualification Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT q.Qualification_ID,q.Emp_ID,e.First_Name,q.Level,q.Institute,q.Year,q.Score,q.Start_Date,q.End_Date,l.Language_Name,s.Skill_Name,q.Year_of_experience,q.Company,q.From_Date,q.To_Date from qualification as q,emp_personaldetail as e,language as l,skill as s where q.Emp_ID=e.Emp_ID AND l.Language_ID=q.Language AND s.Skill_ID=q.Skill ORDER BY q.Qualification_ID";
		
		$arr=array("Emp_ID","First Name","Level","Institute","Year","Score","Start_Date","End_Date","Language","Skill","Year_of_experience","Company","From_Date","To_Date");
		echo displayData($arr,$q,"update_qualification.php","display_qualification.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>