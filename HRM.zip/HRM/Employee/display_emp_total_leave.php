<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_total_leave WHERE EmpTotalLeave_ID=".$id;
	exenonQuery($q);
	header("location:display_emp_total_leave.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee total leave Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee total leave Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT e1.EmpTotalLeave_ID,e1.Emp_ID,e.First_Name,e1.Emp_Leave_ID,e1.Total_Leave_Days,e1.Reason from emp_total_leave as e1,emp_personaldetail as e where e.Emp_ID=e1.Emp_ID ORDER BY e1.EmpTotalLeave_ID";
		
		
		$arr=array("Emp_ID","First Name","Emp_Leave_ID","Total_Leave_Days","Reason");
		echo displayData($arr,$q,"update_emp_total_leave.php","display_emp_total_leave.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>