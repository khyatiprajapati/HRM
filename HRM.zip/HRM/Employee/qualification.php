<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("qualification","Qualification_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Qualification Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Qualification Detail</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="txtEmp_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Level</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtLevel" name="txtLevel">
											<div id="txtLevel1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Institute</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtInstitutel" name="txtInstitute">
											<div id="txtInstitute1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Specialization</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtSpecialization" name="txtSpecialization">
											<div id="txtSpecialization1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Year</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtYear" name="txtYear">
											<div id="txtYear1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Score</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txxScore" name="txxScore">
											<div id="txxScore1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Start Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtStart_Date" id="txtStart_Date">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">End Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtEnd_Date" id="txtStart_Date">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">Language</label>
										<div class="controls">
											<?php $emp="select Language_ID,Language_Name from language";?>
											<select name="cmbLanguage" id="cmbLanguage">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbLanguage1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Fluency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFluency" name="txtFluency">
											<div id="txtFluency1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input501">Competency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCompetency" name="txtCompetency">
											<div id="txtCompetency1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Language Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtLanguage_comment" id="txtLanguage_comment"></textarea>
											<div id="txtLanguage_comment1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Skill</label>
										<div class="controls">
											<?php $emp="select Skill_ID,Skill_Name,Description from skill";?>
											<select  name="cmbSkill" id="cmbSkill">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="ttxSkill_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Year Of Experience</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtYear_of_experience" name="txtYear_of_experience">
											<div id="txtYear_of_experience1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Skill Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtSkill_comment" id="txtSkill_comment"></textarea>
											<div id="txtSkill_comment1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input501">Company</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCompany" name="txtCompany">
											<div id="txtCompany1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Job Title</label>
										<div class="controls">
											<?php $emp="select JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select  name="cmbJob_Title" id="cmbJob_Title">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="ttxJobTitle_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">From Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtFrom_Date" id="txtFrom_Date">
											<div id="txtFrom_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">To Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtTo_Date" id="txtTo_Date">
											<div id="txtTo_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Experience Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtExperience_Comment" id="txtExperience_Comment"></textarea>
											<div id="txtExperience_Comment1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>