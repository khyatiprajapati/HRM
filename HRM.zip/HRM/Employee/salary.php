<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("salary","Salary_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Add Salary</title>
<script src="validation.js" language="javascript"></script>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Salary Information <a href="display_salary.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Salary Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Job Title </label>
										<div class="controls">
											<?php $job="SELECT JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBox($job);?>
											</select>
											<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Minimum Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMinSalary" name="txtMinSalary">
											<div id="txtMinSalary1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Maximum Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMaxSalary" name="txtMaxSalary">
											<div id="txtMaxSalary1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">PayFrequency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPayFrequency" name="txtPayFrequency">
											<div id="txtPayFrequency1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>