<?php
include("include/session.php");


$q1="select * from emp_personaldetail where Emp_ID=".$_SESSION['Emp_ID'];
$rs1= mysql_query($q1,$cn) or die("Error:".mysql_error());
$row= mysql_fetch_array($rs1);
		

?>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/jquery-ui-1.8.16.custom.css" rel="stylesheet">
<link href="css/jquery.jqplot.css" rel="stylesheet">
<link href="css/prettify.css" rel="stylesheet">
<link href="css/elfinder.min.css" rel="stylesheet">
<link href="css/elfinder.theme.css" rel="stylesheet">
<link href="css/fullcalendar.css" rel="stylesheet">
<link href="js/plupupload/jquery.plupload.queue/css/jquery.plupload.queue.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="css/icons-sprite.css" rel="stylesheet">
<link id="themes" href="css/themes.css" rel="stylesheet">
<script src="js/validation.js" type="text/javascript"></script>
</head>
<body>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner top-nav">
    <div class="container-fluid">
      <div class="branding">
        <div class="logo"> <a href="update_emp_personaldetail.php" style="font-size:16px;color:#FFFFFF;font-weight:bold">Human Resource Management</a> </div>
      </div>
      <ul class="nav pull-right">        
        <li class="dropdown"><a data-toggle="dropdown" class="dropdown-toggle" href="#"><?php echo $row['First_Name']; ?><i class="white-icons admin_user"></i><b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="update_emp_personaldetail.php"><i class="icon-pencil"></i> Edit Profile</a></li>
            <li class="divider"></li>
            <li><a href="logout.php"><i class="icon-off"></i><strong>Logout</strong></a></li>
          </ul>
        </li>
      </ul>
      <button data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar" type="button"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
      
	  <div class="nav-collapse collapse">
        <ul class="nav">
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="nav-icon list"></i>Leaves <b class="caret"></b></a>
            <ul class="dropdown-menu">
			<ul class="acitem">
        <li><a href= "display_leave_assign.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Leave Assign</a></li>
        <li><a href="display_leave_period.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Leave Period</a></li>
        <li><a href="display_leave_type.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Leave Type</a></li>
        <li><a href="display_Work_Week.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Work Week</a></li>
        <li><a href="display_holidays.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Holidays</a></li>
      </ul>
	  </ul>
	</li>
		<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="nav-icon money"></i>Salary<b class="caret"></b></a>
            <ul class="dropdown-menu">
			<ul class="acitem">
 
			<li><a href="display_salary.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Salary</a></li>
        <li><a href="display_salary_component.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Salary Component</a></li>
		<li><a href="display_payment.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Payment</a></li>
      </ul>
	  </ul>
	  </li>
	  
	  
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="nav-icon cog_3"></i> Themes Settings<b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li class="nav-header">Colors</li>
              <li class=" clearfix color-block"><span class="theme-color theme-blue" title="theme-blue"></span><span class="theme-color theme-light-blue" title="theme-light-blue"></span><span class="theme-color theme-dark" title="theme-dark"></span><span class="theme-color theme-chrome" title="theme-chrome"></span><span class="theme-color theme-chayam" title="theme-chayam"></span><span class="theme-color theme-default" title="theme-default"></span></li>
               <li class=" divider"></li>
              <li class="nav-header hidden-phone hidden-tablet">Sidebar Placement</li>
              <li class="theme-settings clearfix hidden-phone hidden-tablet">
                <div class="btn-group">
                  <button disabled="disabled" id="left-sidebar" class="btn btn-inverse">Left</button>
                  <button id="right-sidebar" class="btn btn-info">Right</button>
                </div>
              </li>
             
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>

<div id="sidebar">
  <ul class="side-nav accordion_mnu collapsible">
    <li><a href="update_emp_personaldetail.php"><span class="white-icons computer_imac"></span>Employee</a></li>
	

	 <ul class="acitem">
        <li><a href="login1.php"><span class="sidenav-icon"><span class="sidenav-link-color"></span></span>Login</a></li>
      </ul>
	  
	  <li><a href="#"><span></span><img src="../Admin/images/employee/<?php echo $row['image_name'];?>"><?php echo $row['First_Name']." ".$row['Middle_Name']." ".$row['Last_Name'];?></a> 
	   <li><a href="update_emp_personaldetail.php"><span class="white-icons documents"></span>Personal Detail</a>
	    <li><a href="update_emp_contactdetail.php"><span class="white-icons documents"></span>Contact Detail</a>
		 <li><a href="update_emp_dependate.php"><span class="white-icons documents"></span>Dependate Detail</a>
		 <li><a href="update_emp_emergencycontact.php"><span class="white-icons documents"></span>EmergencyContact</a>
		 <li><a href="update_emp_total_leave.php"><span class="white-icons documents"></span>Total Leave</a>
		 <li><a href="update_qualification.php"><span class="white-icons documents"></span>Qualification</a>
		 <li><a href="update_emp_training.php"><span class="white-icons documents"></span>Employee Training</a>
		 <li><a href="update_job.php"><span class="white-icons documents"></span>Job</a>
		</ul>
	</li>
   
</div>