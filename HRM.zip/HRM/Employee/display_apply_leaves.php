<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM apply_leaves WHERE Empleave_ID=".$id;
	exenonQuery($q);
	header("location:display_apply_leaves.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Apply Leaves</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> Apply Leaves<a href="apply_leaves.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add Apply Leaves</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT a1.Empleave_ID,a1.Emp_ID,e1.First_Name,a1.To_Date,a1.From_Date,a1.Reason,a1.Status,a1.approve_date from apply_leaves as a1,emp_personaldetail as e1 where e1.Emp_ID=a1.Emp_ID ORDER BY a1.Empleave_ID";
		
		$arr=array("Emp_ID","First Name","To_Date","From_Date","Reason","Status","approve_date");
		echo displayData($arr,$q,"update_apply_leaves.php","display_apply_leaves.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>