<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM job_vacancy WHERE JobVacancy_ID=".$id;
	exenonQuery($q);
	header("location:display_job_vacancy.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Job Vacancy Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Job Vacancy Detail<a href="job_vacancy.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Job Vacancy Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT j.JobVacancy_ID,v.Vacancy,j1.Job_Category,j.Hiring_Manager,j.Number_of_Position,j.Description from job_vacancy as j,vacancy as v,job as j1 where  v.Vacancy_ID=j.Vacancy_ID AND j1.Job_ID=j.Job_ID ORDER BY j.JobVacancy_ID";
		$arr=array("Vacancy","Job_Category","Hiring_Manager","Number_of_Position","Description");
		echo displayData($arr,$q,"update_job_vacancy.php","display_job_vacancy.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>