<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_dependate","Emp_Dependent_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Department Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Department Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											<div id="cmbEmp_ID1"></div>
											</select>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtName" name="txtName">
											<div id="txtName1"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">Relationship</label>
										<div class="controls">
											<select name="cmbRelationship" id="cmbRelationship">
												<option value="select">Select</option>
												<option value="Friend">Friend</option>
												<option value="Sister">Sister</option>
												<option value="Brother">Brother</option>
                                                <option value="Father">Father</option>		
											</select>
											<div id="cmbRelationship1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>