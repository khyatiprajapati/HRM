<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("company_info","Company_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>  HRM  | Company Information </title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Company Information<a href="display_company_info.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Company Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Company Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtCompany_Name" name="txtCompany_Name">
											<div id="txtCompany_Name"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Address1</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtAddress1" id="txtAddress1"></textarea>
											<div id="txtAddress11"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Address2</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtAddress2" id="txtAddress2"></textarea>
											<div id="txtAddress21"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">Number of Employee</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtNumber_of_employee" name="txtNumber_of_employee">
											<div id="txtNumber_of_employee1"></div>
										</div>
									</div>	
									
										<div class="control-group">
										<label class="control-label">City</label>
										<div class="controls">
											<?php $city="select City_ID,City_Name from city";?>
											<select name="cmbCity_ID" id="cmbCity_ID">
												<?php echo FillComboBox($city);?>
												</select>
											<div id="cmbCity_ID1"></div>
										</div>	
									</div>
									
									<div class="control-group">
										<label class="control-label">State</label>
										<div class="controls">
												<?php $state="select State_ID,State_Name from State";?>
												<select name="cmbState_ID" id="cmbState_ID">
												<?php echo FillComboBox($state);?>
												</select>
											<div id="cmbState_ID1"></div>
										</div>	
									</div>
										
										<div class="control-group">
										<label class="control-label">Country</label>
										<div class="controls">
											<?php $country="select Country_ID,Country_Name from country";?>
											<select name="cmbCountry_ID" id="cmbCountry_ID">
													<?php echo FillComboBox($country);?>
											</select>
											<div id="cmbCountry_ID1"></div>
										</div>	
									</div>
										
										<div class="control-group">
										<label class="control-label">Phone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPhone" name="txtPhone">
											<div id="txtPhone1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmail_ID" name="txtEmail_ID">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Registration No</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtRegistration_No" name="txtRegistration_No">
											<div id="txtRegistration_No1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input502">Tax Id</label>
										<div class="controls">
											<input type="text" class="input-xlarge" name="txtTax_ID" id="txtTax_ID"/>
											<div id="txtTax_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label" for="input502">Fax</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtFax" name="txtFax"/>
											<div id="txtFax1"></div>
										</div>
									</div>
									
					
									<div class="control-group">
										<label class="control-label">Pin Code</label>
										<div class="controls">
											<input class="input-xlarge" type="text" name="txtPin_Code" id="txtPin_Code">
											<div id="txtPin_Code1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Note</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtNote" id="txtNote"></textarea>
											<div id="txtNote1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>