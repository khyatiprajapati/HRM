<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM admin WHERE Admin_ID=".$id;
	exenonQuery($q);
	header("location:display_admin.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Admin Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Admin Detail<a href="admin.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Admin Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT Admin_ID,Admin_Name,Gender,Date_Of_Birth,Email_ID,Password from admin";
		$arr=array("Admin_Name","Gender","Date_Of_Birth","Email_ID","Password");
		echo displayData($arr,$q,"update_admin.php","display_admin.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>