<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM salary_component WHERE Salary_Component_ID=".$id;
	exenonQuery($q);
	header("location:display_salary_component.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM |Salary Detail </title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Salary Detail </h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT s.Salary_Component_ID,e.First_Name,j.Job_Title,s.Amount,s.Pay_Method,s.Bank_Name,s.Account_Number from salary_component as s,emp_personaldetail as e,jobtitle as j where s.Emp_ID=e.Emp_ID AND s.JobTitle_ID=j.JobTitle_ID ORDER BY s.Salary_Component_ID ";
		$arr=array("First Name","Job Title","Amount","Pay_Method","Bank_Name","Account_Number");
		echo displayData($arr,$q,"update_salary_component.php","display_salary_component.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>