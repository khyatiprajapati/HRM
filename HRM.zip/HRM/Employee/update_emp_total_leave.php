<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_total_leave WHERE Emp_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	
	$id_c=$row['EmpTotalLeave_ID'];
	
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_total_leave","$id_c","EmpTotalLeave_ID","");
	header("location:update_emp_total_leave.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee total leave Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee total leave Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
										<div class="control-group">
										<label class="control-label">Employee Leave ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmp_Leave_ID" name="txtEmp_Leave_ID" value="<?php echo $row1['Emp_Leave_ID'];?>"> 
											<div id="txtEmp_Leave_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Total Leave Days</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtTotal_Leave_Days" name="txtTotal_Leave_Days" value="<?php echo $row1['Total_Leave_Days'];?>">
											<div id="txtTotal_Leave_Days1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Reason</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtReason" id="txtReason" value="<?php echo $row1['Reason'];?>"></textarea>
											<div id="txtReason1"></div>
										</div>
									</div>
								
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>