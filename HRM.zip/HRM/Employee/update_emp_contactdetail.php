<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_contactdetail WHERE Emp_ID=".$id;
	//echo $selectQuery; exit;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);
	//echo $row['Postal_code']; exit;
	//print_r($row1) ; exit;
	$id_c = $row['Emp_Contact_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_contactdetail","$id_c","Emp_Contact_ID","");
	header("location:update_emp_contactdetail.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Contact Information</title>
<?php include('header.php');?>

<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg; ?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
											<div class="control-group">
											<label class="control-label">Address1</label>
											<div class="controls">
												<textarea class="input-xlarge" rows="3" name="txtAddress1" id="txtAddress1" >
												<?php 
												echo $row1['Address1'];?>
												</textarea>
											<div id="txtAddress11"></div>
										</div>
									</div>
									
									<div id="txtCompany_name1"></div>
											<div class="control-group">
											<label class="control-label">Address2</label>
											<div class="controls">
												<textarea class="input-xlarge" rows="3" name="txtAddress2" id="txtAddress2" ><?php 
												echo $row1['Address2'];?>
												
												</textarea>
											<div id="txtAddress21"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">City</label>
										<div class="controls">
										<?php $city="select City_ID,City_Name from city";?>
											<select name="cmbCity_ID" id="cmbCity_ID">
											<?php echo FillComboBoxUpdate($city,$row1['City_ID']);?>
											</select>
											<div id="cmbCity_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">State</label>
										<div class="controls">
										<?php $state="select State_ID,State_Name from state";?>
											<select name="cmbState_ID" id="cmbState_ID">
											<?php echo FillComboBoxUpdate($state,$row1['State_ID']);?>
											</select>
											<div id="cmbState_ID1"></div>
										</div>
									</div>

									<div class="control-group">
										<label class="control-label">Postal code</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPostal_code" name="txtPostal_code" value="<?php echo $row1['Postal_code'];?>">
											<div id="txtPostal_code1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Country</label>
										<div class="controls">
											<?php $country="select Country_ID,Country_Name from country";?>
											<select name="cmbCountry_ID" id="cmbCountry_ID">
											<?php echo FillComboBoxUpdate($country,$row1['Country_ID']);?>
											</select>
											<div id="cmbCountry_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Home Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" name="txtHome_Telephone" id="txtHome_Telephone" value="<?php echo $row1['Home_Telephone'];?>">
											<div id="txtHome_Telephone1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Mobile</label>
										<div class="controls">
											<input type="text" class="input-xlarge"  name="txtMoblie" id="txtMoblie" value="<?php echo $row['Mobile'];?>">
											<div id="txtMobile1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Work Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtWork_Telephone" name="txtWork_Telephone" value="<?php echo $row1['Work_Telephone'];?>">
											<div id="txtWork_Telephone1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Work Email</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtWork_Email" name="txtWork_Email" value="<?php echo $row1['Work_Email'];?>">
											<div id="txtWork_Email1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Other Email</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtOther_Email" name="txtOther_Email" value="<?php echo $row1['Other_Email'];?>">
											<div id="txtOther_Email1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>