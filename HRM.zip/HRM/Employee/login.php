<html>
<head>
<title>The Login page</title>
</head>
<body>
<?php
if (isset($_POST['submit']))
 {
    require_once("mysql_connect.php");                                                        #1
    if (!empty($_POST['email'])) {
        $e =($_POST['email']);
    } 
	else 
	{
		$e = FALSE;
        echo '<p class="error">You forgot to enter your email 
address.</p>';
    }
    if (!empty($_POST['psword']))
	{
            $p =$_POST['psword'];
    } 
	else 
	{
		$p = FALSE;
        echo '<p class="error">You forgot to enter your password.</p>';
    }
    if ($e && $p)
	{
		$q = "SELECT user_id, fname, user_level FROM users 
WHERE (email='$e' AND psword=SHA1('$p'))";
		//echo $q;
		$result = mysql_query($q);
		//echo $result;
		if(mysql_num_rows($result) == 1)
		{
			session_start();                                                                           
			$_SESSION = mysql_fetch_array ($result);
			$_SESSION['user_level'] = (int) $_SESSION
['user_level'];
			$url = ($_SESSION['user_level'] === 1) 
 'admin-page.php' : 'members-page.php';
			header('Location: ' . $url);
			exit(); 
			mysql_free_result($result);
			mysql_close();
    } 
	else 
	{
		echo '<p class="error">The e-mail address and 
password entered do not match our records ?
		<br>Perhaps you need to register</p>';
    }
   } 
	else
	{ 
		echo '<p class="error">Please try again.</p>';
    }
    mysql_close();
}
?>
<h2>Login</h2>
<form action="file:///H|/login page/login.php" method="post">
<p><label class="label" for="email">Email Address:</label>
<input id="email" type="text" name="email" size="30" maxlength="60" ?
value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" > </p>
<br>
<p><label class="label" for="psword">Password:</label>
<input id="psword" type="password" name="psword" size="12" maxlength="12" ?
value="<?php if (isset($_POST['psword'])) echo $_POST['psword']; ?>" > ?
<span>&nbsp;Between 8 and 12 characters.</span></p>
<p>&nbsp;</p><p>
<input id="submit" type="submit" name="submit" value="Login"></p>
<a href="file:///H|/login page/register-page.php">register</a>
</form><br>
 
</body>
</html>
