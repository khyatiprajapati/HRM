<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("user_contact","Contact_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Add  User Contact</title>
<script src="validation.js" language="javascript"></script>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> User Contact Information <a href="display_user_contact.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display  User Contact Information</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">User Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtUser_Name" name="txtUser_Name">
											<div id="txtUser_Name1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmail_ID" name="txtEmail_ID">
											<div id="txtEmail_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Subject</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtSubject" name="txtSubject">
											<div id="txtSubject1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Message</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtMessage" id="txtMessage"></textarea>
											<div id="txtMessage1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>