<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM emp_emergencycontact WHERE Emp_EmergencyContact_ID=".$id;
	exenonQuery($q);
	header("location:display_emp_emergencycontact.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> HRM | Employee Emergency Contact Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Emergency Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT e1.Emp_EmergencyContact_ID,e1.Emp_ID,e1.Name,e.Relationship,e1.Home_Telephone,e1.Mobile,e1.Work_Telephone FROM emp_emergencycontact as e1,emp_dependate as e where e.Emp_Dependent_ID=e1.Emp_Dependent_ID ORDER BY e1.Emp_EmergencyContact_ID";
		
		$arr=array("Emp_ID","Name","Realtionship","Home_Telephone","Mobile","Work_Telephone");
		echo displayData($arr,$q,"update_emp_emergencycontact.php","display_emp_emergencycontact.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>