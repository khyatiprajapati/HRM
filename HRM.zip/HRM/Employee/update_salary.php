<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM salary WHERE Salary_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("salary","$id","Salary_ID","");
	header("location:display_salary.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Salary Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> Salary Information<a href="display_salary.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Salary INFORAMTION</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Job Title </label>
										<div class="controls">
										<?php $job="SELECT JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBoxUpdate($job,$row['JobTitle_ID']);?>
											</select>
											 
											<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Minimum Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMinSalary" name="txtMinSalary" value="<?php echo $row['MinSalary'];?>">
											<div id="txtMinSalary1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Maximum Salary</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMaxSalary" name="txtMaxSalary" value="<?php echo $row['MaxSalary'];?>">
											<div id="txtMaxSalary1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">PayFrequency</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPayFrequency" name="txtPayFrequency" value="<?php echo $row['PayFrequency'];?>">
											<div id="txtPayFrequency1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>