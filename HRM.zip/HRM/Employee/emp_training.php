<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_training","Emp_Training_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Employee Training Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Employee Training Information<a href="display_emp_training.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Employee Training Information </a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
										<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>

											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbEmp_ID1"></div>
											
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">JobTitle ID</label>
										<div class="controls">
										
										<?php $job="select JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBox($job);?>
											
											</select>
												<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
									
											<div class="control-group">
										<label class="control-label">Training ID</label>
										<div class="controls">
											<?php $training="select Training_ID,Training_Name,To_Date,From_Date,Place,Description from training";?>
											<select name="cmbTraining_ID" id="cmbTraining_ID">
												<?php echo FillComboBox($training);?>
											
										</select>
											<div id="cmbTraining_ID1"></div>
										</div>
									</div>
																		
										<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>