<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
$cn=getCon();
if(isset($_REQUEST['btnsubmit']))
{
	insertData("job","Job_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\">�</button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>>
<title>HRM |Job Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
	
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5> Job Detail</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Employee Name</label>
										<div class="controls">
											<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
										<div id="cmbEmp_ID1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label" for="input501">Job Title </label>
										<div class="controls">
											<?php $job="select JobTitle_ID,Job_Title,Job_Description,Job_Specification,Note from jobtitle";?>
											<select name="cmbJobTitle_ID" id="cmbJobTitle_ID">
												<?php echo FillComboBox($job);?>
											</select>
										<div id="cmbJobTitle_ID1"></div>
										</div>
									</div>
										<div class="control-group">
										<label class="control-label" for="input501">Job Specification</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtJob_Specification" name="txtJob_Specification">
											<div id="txtJob_Specification1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Employment Status</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtEmployment_Status" name="txtEmployment_Status">
											<div id="txtEmployment_Status1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Job Category</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtJob_Category" name="txtJob_Category">
											<div id="txtJob_Category1"></div>
										</div>
									</div>
									
									
									
									<div class="control-group">
										<label class="control-label">Joined Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtJoined_Date" id="txtJoined_Date">
											<div id="txtJoined_Date1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Location</label>
										<div class="controls">
											<input class="input-file" type="text" name="txtLocation" id="txtLocation">
											<div id="txtLocation1"></div>
										</div>
									</div>
									
									
									
									<div class="control-group">
										<label class="control-label">Start Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtStart_Date" id="txtStart_Date">
											<div id="txtStart_Date1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">End Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtEnd_Date" id="txtEnd_Date">
											<div id="txtEnd_Date1"></div>
										</div>
									</div>
									
									
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>