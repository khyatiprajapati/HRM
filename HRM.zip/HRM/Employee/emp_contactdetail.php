<?php 
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
	insertData("emp_contactdetail","Emp_Contact_ID","");
	$msg="<div class=\"alert alert-success fade in\"><button data-dismiss=\"alert\" class=\"close\" type=\"button\"></button><strong>Success!</strong> Data Save successfully.</div>";
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>  HRM  | Contact Information </title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Contact Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
										<?php $emp="select Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID">
												<?php echo FillComboBox($emp);?>
											</select>
											<div id="cmbEmp_ID1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Address1</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtAddress1" id="txtAddress1"></textarea>
											<div id="txtAddress11"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Address2</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtAddress2" id="txtAddress2"></textarea>
											<div id="txtAddress21"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">City</label>
										<div class="controls">
										<?php $city="select City_ID,City_Name from city";?>
											<select name="cmbCity_ID" id="cmbCity_ID">
												<?php echo FillComboBox($city);?>
											</select>
											<div id="cmbCity_ID1"></div>
										</div>	
									</div>
									
										<div class="control-group">
										<label class="control-label">State</label>
										<div class="controls">
										<?php $state="select State_ID,State_Name from state";?>
											<select name="cmbState_ID" id="cmbState_ID">
												<?php echo FillComboBox($state);?>
												</select>
												<div id="cmbState_ID1"></div>
											</div>	
									</div>
									
										<div class="control-group">
										<label class="control-label">Postal code</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtPostal_code" name="txtPostal_code">
											<div id="txtPostal_code1"></div>
										</div>
									</div>	
									
										<div class="control-group">
										<label class="control-label">Country</label>
										<div class="controls">
										<?php $country="select Country_ID,Country_Name from country";?>
											<select name="cmbCountry_ID" id="cmbCountry_ID">
													<?php echo FillComboBox($country);?>
											</select>
											<div id="cmbCountry_ID1"></div>
										</div>	
									</div>
									
										<div class="control-group">
										<label class="control-label">Home Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtHome_Telephone" name="txtHome_Telephone">
											<div id="txtHome_Telephone1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Mobile</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtMoblie" name="txtMoblie">
											<div id="txtMoblie1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Work Telephone</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtWork_Telephone" name="txtWork_Telephone">
											<div id="txtWork_Telephone1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Work Email</label>
										<div class="controls">
											<input type="text" class="input-xlarge" name="txtWork_Email" id="txtWork_Email">
											<div id="txtWork_Email1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Other Email</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtOther_Email" name="txtOther_Email">
											<div id="txtOther_Email1"></div>
										</div>
									</div>
									
									<div class="form-actions">
										<input type="submit" class="btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>