<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM punch_out WHERE PunchOut_ID=".$id;
	exenonQuery($q);
	header("location:display_punch_out.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM|Punch Out Detail</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Punch Out Detail<a href="punch_out.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Punch Out Detail</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT p.PunchOut_ID,p.Emp_ID,e.First_Name,p.PunchOut_Date,p.PunchOut_Time,p.PunchOut_Note from punch_out as p,emp_personaldetail as e where e.Emp_ID=p.Emp_ID ORDER BY p.PunchOut_ID";
		$arr=array("Emp_ID","First Name","PunchOut_Date","PunchOut_Time","PunchOut_Note");
		echo displayData($arr,$q,"update_punch_out.php","display_punch_out.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>