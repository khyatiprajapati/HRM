<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_SESSION['Emp_ID']))
{
	$id=$_SESSION['Emp_ID'];
	$selectQuery="SELECT * FROM emp_dependate WHERE Emp_ID=".$id;
	
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$rs1=mysql_query($selectQuery,$cn) or die("".mysql_error());
	
	$row=mysql_fetch_array($rs);
	$row1=mysql_fetch_array($rs1);

	
	$id_c=$row['Emp_Dependent_ID'];
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("emp_dependate","$id_c","Emp_Dependent_ID","");
	header("location:update_emp_dependate.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM |Department Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Department Information</h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									
									<div class="control-group">
										<label class="control-label">Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtName" name="txtName" value="<?php echo $row1['Name'];?>">
											<div id="txtName1"></div>
										</div>
									</div>
									
										<div class="control-group">
										<label class="control-label">Relationship</label>
										<div class="controls">
										<?php $gen = $row['Relationship'];?>
											<select name="cmbRelationship" id="cmbRelationship">
												<option value="select">Select</option>
												<?php
												if($gen=='Friend'){
												?>
													<option value="Friend" selected >Friend</option>
													<option value="Sister">Sister</option>													
												<?php
												}
												else if($gen=='Sister'){
												?>
												<option value="Sister" selected >Sister</option>
												<option value="Brother">Brother</option>	
												<?php } 
												else if($gen=='Brother')
												?>	
												<option value="Female">Female</option>	
												<option value="Brother" selected >Brother</option>
											</select>
											<div id="cmbRelationship1"></div>
										</div>
									</div>							
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>