<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
$cn=getCon();
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM apply_leaves WHERE Empleave_ID=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("apply_leaves",$id,"Empleave_ID");
	header("location:display_apply_leaves.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Apply Leaves</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Apply Leaves<a href="display_apply_leaves.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Apply Leaves</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label">Employee Name</label>
										<div class="controls">
											<?php $emp="SELECT Emp_ID,First_Name,Middle_Name,Last_Name,image_name,DrivingLicence_No,DrivingLicence_Expirydate,Gender,Mertial_Status,Nationality,Date_of_birth,Password from emp_personaldetail";?>
											<select name="cmbEmp_ID" id="cmbEmp_ID" value="<?php echo $row['Emp_ID'];?>">
												<?php echo FillComboBoxUpdate($emp,$row['Emp_ID']);?>
											</select>
											<div id="cmbEmp_ID1"></div>
										</div>
									</div>
									
									
									<div class="control-group">
										<label class="control-label">To Date</label>
											<div class="controls">
												<div class="input-append">
													<input class="input-large" type="date" name="txtTo_Date" id="txtTo_Date" value="<?php echo $row['To_Date'];?>">
												
												<h6><div id="txtTo_Date"></div></h6>
												</div>
											</div>
										</div>
											
									
										<div class="control-group">
										<label class="control-label">From Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtFrom_Date" id="txtFrom_Date" value="<?php echo $row['From_Date'];?>">
											<div id="txtFrom_Date1"></div>
										</div>
									</div>
									   <div class="control-group">
										<label class="control-label">Reason</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtReason" id="txtReason"></textarea>
											<div id="txtReason1"></div>
										</div>
									</div>
									
									
										<div class="control-group">
										<label class="control-label">Status</label>
										<div class="controls">
											<select name="cmbStatus" id="cmbStatus" value="<?php echo $row['Status'];?>">
												<option value="Approved">Approved</option>
												<option value="Unapproved">Unapproved</option>
												</select>
											<div id="cmbStatus1"></div>
										</div>
									</div>
									
									<div class="control-group">
										<label class="control-label">Approve Date</label>
										<div class="controls">
											<input class="input-large" type="date" name="txtapprove_date" id="txtapprove_date" value="<?php echo $row['approve_date'];?>">
											<div id="txtapprove_date1"></div>
										</div>
									</div>
									
									
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Submit">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>