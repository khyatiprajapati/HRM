<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM training WHERE Training_ID=".$id;
	exenonQuery($q);
	header("location:display_training.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>HRM | Training Information</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Training Information<a href="training.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Training</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="select Training_ID,Training_Name,To_Date,From_Date,Place,Description from training" ;
		$arr=array("Training_Name","To_Date","From_Date","Place","Description");
		echo displayData($arr,$q,"update_training.php","display_training.php","");
							?>
						</div>
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>