<?php
include("include/session.php");
include("include/connection.php");
$msg="";
$con=getCon();
if(isset($_REQUEST['btnin']))
{
	$select="SELECT * FROM emp_personaldetail WHERE Emp_ID=".$_SESSION['Emp_ID'];
	$qry=mysql_query($select,$con)or die(mysql_error());
	$row=mysql_fetch_array($qry);
	// $_SESSION['Emp_ID'];
	//exit;
	$qry11="INSERT INTO punch_in(Emp_ID,PunchIn_Date,PunchIn_Time,PunchIn_Note) VALUES(".$row[0].",'".date('m-d-Y')."','".$_POST['txtTime']."','".$_POST['txtPunchIn_Note']."')";
	
	
	$r=mysql_query($qry11,$con)or die(mysql_error());
	//header("location:index.php");
}	
?>		
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Human Resource Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- styles -->
<link href="css/bootstrap.css" rel="stylesheet"> 
<link href="css/jquery-ui-1.8.16.custom.css" rel="stylesheet">
<link href="css/jquery.jqplot.css" rel="stylesheet">
<link href="css/prettify.css" rel="stylesheet">
<link href="css/elfinder.min.css" rel="stylesheet">
<link href="css/elfinder.theme.css" rel="stylesheet">
<link href="css/fullcalendar.css" rel="stylesheet">
<link href="js/plupupload/jquery.plupload.queue/css/jquery.plupload.queue.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="css/icons-sprite.css" rel="stylesheet">
<link id="themes" href="css/themes.css" rel="stylesheet">
</head>
<body>
<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container-fluid">
			<div class="branding">
				<div class="logo">
						<a href="index.html"><a href="" style="font-size:16px;color:#FFFFFF;font-weight:bold">Human Resource Management</a> </a>
				</div>
			</div>
				<ul class="nav pull-right">
				<li>Welcome <?php echo $_SESSION['Emp_ID'];?> |</li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
	</div>
</div>

<div class="login-container">
	<div class="well-login">
		<h3 style="text-align:center"> <span>Punch In</span></h3>&nbsp;
		
		<form method="post" enctype="multipart/form-data" onSubmit="return validate(this);" name="frm">
        <table border="0" id="input">
          <tr>
              <td style="border:none">Date</td>
              <td style="border:none">:</td>
               <td style="border:none"> <div id="date">
                  <script type="text/javascript">
					var d=new Date();
					var d1=d.getMonth('M')+1+"-"+d.getDate()+"-"+d.getFullYear();
					document.getElementById('date').innerHTML=d1;
					
				</script>
                  <script type="text/javascript">
					var d=new Date();
					var d1=d.getMonth('M')+1+"-"+d.getDate()+"-"+d.getFullYear();
					document.getElementById('date').innerHTML=d1;
					
				</script>
                </div></td>
            </tr>
            <tr>
              <td style="border:none">Time</td>
              <td style="border:none">:</td>
              <td style="border:none"><input type="hidden" name="txtTime" id="txtTime"/>
                <div id="time">
                  <script type="text/javascript">
					var t=new Date();
					var t1=t.getHours()+":"+t.getMinutes()+":"+t.getSeconds();
					document.getElementById('time').innerHTML=t1;
					document.getElementById('txtTime').value=t1;
				</script>
                </div></td>
            </tr>
           <tr>
            <td style="border:none">Enter Note</td>
            <td style="border:none">:</td>
            <td style="border:none">
            <textarea name="txtPunchIn_Note" class="textarea" ></textarea>
              <div id="txtPunchIn_Note1"></div></td>
          </tr>
           <tr>
            <td style="border:none"></td>
            <td style="border:none"></td>
            <td style="border:none"><input class="btn btn-inverse" type="submit" name="btnin" id="btnin" value="PunchIN">
             </td>
          </tr>
        </table>
      </form>
	</div>
</div>

<script src="js/jquery.js"></script>
<script src="js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/prettify.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/accordion.jquery.js"></script>
<script src="js/smart-wizard.jquery.js"></script>
<script src="js/vaidation.jquery.js"></script>
<script src="js/jquery-dynamic-form.js"></script>
<script src="js/fullcalendar.js"></script>
<script src="js/raty.jquery.js"></script>
<script src="js/jquery.noty.js"></script>
<script src="js/jquery.cleditor.min.js"></script>
<script src="js/data-table.jquery.js"></script>
<script src="js/TableTools.min.js"></script>
<script src="js/ColVis.min.js"></script>
<script src="js/plupload.full.js"></script>
<script src="js/elfinder/elfinder.min.js"></script>
<script src="js/chosen.jquery.js"></script>
<script src="js/uniform.jquery.js"></script>
<script src="js/jquery.tagsinput.js"></script>
<script src="js/jquery.colorbox-min.js"></script>
<script src="js/check-all.jquery.js"></script>
<script src="js/inputmask.jquery.js"></script>
<script src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>
<script src="js/plupupload/jquery.plupload.queue/jquery.plupload.queue.js"></script>
<script src="js/excanvas.min.js"></script>
<script src="js/jquery.jqplot.min.js"></script>
<script src="js/chart/jqplot.highlighter.min.js"></script>
<script src="js/chart/jqplot.cursor.min.js"></script>
<script src="js/chart/jqplot.dateAxisRenderer.min.js"></script>
<script src="js/custom-script.js"></script>
<script src="js/respond.min.js"></script>
<script src="js/ios-orientationchange-fix.js"></script>
</body>
</html>
