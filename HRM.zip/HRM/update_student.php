<?php
ini_set("display_errors",0);
include('include/connection.php');
include("include/session.php");
$id="";
if(isset($_GET['id']))
{
	$cn=getCon();
	$id=$_GET['id'];
	$selectQuery="SELECT * FROM student WHERE student_id=".$id;
	$rs=mysql_query($selectQuery,$cn) or die("".mysql_error());
	$row=mysql_fetch_array($rs);
}
if(isset($_REQUEST['btnsubmit']))
{
	updateData("student","$id","student_id",$updstudent1);
	header("location:display_student.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>TechCrunchSolutions | HRM</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Student Information<a href="display_student.php" class="btn btn-inverse btn-large" style="float:right"><i class="color-icons monitor_co"></i>Display Student</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
						<?php echo $msg;?>
							<form class="form-horizontal well white-box" onSubmit="return validate(this);" method="post" enctype="multipart/form-data">
								<fieldset>
									<div class="control-group">
										<label class="control-label" for="input501">Student Name</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txtstudent_name" name="txtstudent_name" value="<?php echo $row['student_name'];?>">
											<div id="txtstudent_name1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Email ID</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="txxemail_id" name="txxemail_id" value="<?php echo $row['email_id'];?>">
											<div id="txxemail_id1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Mobile No</label>
										<div class="controls">
											<input type="text" class="input-xlarge" id="ttxmobile_no" name="ttxmobile_no" value="<?php echo $row['mobile_no'];?>">
											<div id="ttxmobile_no1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Select City</label>
										<div class="controls">
											<select name="cmbcity_id" id="cmbcity_id">
											<?php
											$q="SELECT city_id,city_name FROM city ORDER BY city_name";
											$cmb=FillComboBoxUpdate($q,$row['city_id']);
											echo $cmb;
											?>
											</select>
											<div id="cmbcity_id1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Gender</label>
										<div class="controls">
											<select name="cmbgender" id="cmbgender">
												<option value="select">Select</option>
												<?php
												if($row['gender']=="Male")
												{
												?>
												<option value="Male" selected="selected">Male</option>
												<option value="Female">Female</option>
												<?php
												}
												else
												{
												?>
												<option value="Male">Male</option>
												<option value="Female" selected="selected">Female</option>
												<?php
												}
												?>
											</select>
											<div id="cmbgender1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input502">Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" name="pwdpassword" id="pwdpassword" value="value="<?php echo $row['password'];?>""/>
											<div id="pwdpassword1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label" for="input502">Confirm Password</label>
										<div class="controls">
											<input type="password" class="input-xlarge" id="cpwpassword" name="cpwpassword" value="value="<?php echo $row['password'];?>""/>
											<div id="cpwpassword1"></div>
										</div>
									</div>
									<div class="input-append date" id="datepicker" data-date="12-02-2012" data-date-format="dd-mm-yyyy">
									<div class="control-group">
									<label class="control-label">Join Date </label>
									<div class="controls">
										<div class="input-append">
											<input size="16" type="text" placeholder="12-02-2015" readonly="readonly" name="txtjoin_date" id="txtjoin_date" value="<?php echo $row['join_date'];?>">
											<span class="add-on margin-fix"><i class="icon-th"></i></span>
										</div>
										<h6><div id="txtjoin_date1"></div></h6>
									</div>
									</div>
									</div>
									<div class="control-group">
										<label class="control-label">Select Image</label>
										<div class="controls">
											<input class="input-file" type="file" name="fileimage_name" id="fileimage_name">
											<div id="fileimage_name1"></div>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">Comment</label>
										<div class="controls">
											<textarea class="input-xlarge" rows="3" name="txtcomment" id="txtcomment"><?php echo $row['comment'];?></textarea>
											<div id="txtcomment1"></div>
										</div>
									</div>
									<div class="form-actions">
										<input type="submit" class="btn btn-primary" name="btnsubmit" value="Save changes">
										<button class="btn">Cancel</button>
									</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>
</body>
</html>