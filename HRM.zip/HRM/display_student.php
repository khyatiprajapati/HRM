<?php
ini_set("display_errors",0);
include("include/connection.php");
include("include/session.php");
$cn=getCon();
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$q="DELETE FROM student WHERE student_id=".$id;
	exenonQuery($q);
	header("location:display_student.php");
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>TechCrunchSolutions | HRM</title>
<?php include('header.php');?>
<div id="main-content">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="widget-block">
					<div class="widget-head">
						<h5>Student Information<a href="student.php" class="btn btn-inverse btn-large" style="float:right"><i class="white-icons download_to_computer"></i>Add New Student</a></h5>
					</div>
					<div class="widget-content">
						<div class="widget-box">
							<?php
		$q="SELECT s1.student_id,s1.student_name,s1.image_name,s1.email_id,s1.mobile_no,c1.city_name,s1.gender,s1.join_date,s1.comment FROM student as s1, city as c1 WHERE s1.city_id=c1.city_id ORDER BY s1.student_name";
		$arr=array("Student Name","Image","Email ID","Mobile No","City","Gender","Join Date","Comment");
		echo displayData($arr,$q,"update_student.php","display_student.php",$updstudent1);
							?>
						</div>
						
					</div>
				</div>
			</div>
		</div>        
	</div>
</div>
<?php include('footer.php');?>
</body>
</html>