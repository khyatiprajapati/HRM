<div class="header_resize">
      <div class="logo">
      <img src="img/logo1.png" width="200px" height="100px" />
              </div>

        
    </div> <!-- end of templatemo header -->
      <div class="menu" style="margin-right:200px;">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="candidate1.php">Vacancy</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact Us</a></li>
        </ul>
      </div>
      <div class="clr"></div>
        </div>
<div class="header">
    
    
  </div>
  