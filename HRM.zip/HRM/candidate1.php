<?php
//include("include/session.php");
include("connection.php");
$msg="";
$cn=getCon();
if(isset($_REQUEST['btnsubmit']))
{
	insertData("candidate_personaldetail","Candidate_Personaldetail_ID",$updfile);
	$msg="<div class=\"message success\"><h5>Success!</h5><p>Data Save Successfully.</p></div>";
}
?>
<html>
<head>
<title>Usersite | Vacancy</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/georgia.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/validation.js" type="text/javascript"></script>

<link href="cssdate/themes/base/jquery.ui.all.css" rel="stylesheet" type="text/css" />
<script src="cssdate/jquery-1.6.4.min.js" type="text/javascript"></script>
<script type="text/javascript" src="cssdate/jquery-ui/jquery.ui.core.min.js"></script>
<script src="cssdate/jquery-ui/jquery.ui.datepicker.min.js" type="text/javascript"></script>
<script src="cssdate/setup.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function () {
		setDatePicker('txtDate_of_Application');
	});
</script>
</head>
<body>
<div class="main">
  <?php include("header.php");?>
	<?php include('fixsidemenu1.php');?>
  <div class="body">
    <div class="headert_text_resize_bg">
      <div class="headert_text_resize"> 
	  
    <div class="body_resize">
      <div class="left" style="width:600px;margin-left:10px;">
        <h2>Apply For Vacancy</h2>
        
        <form method="post" id="contactform" onSubmit="return validate(this);" enctype="multipart/form-data">
			<li>
              <label >Enter First Name</label>
              <label>:</label>
              <input id="txtFirst_Name" name="txtFirst_Name" class="text" />
              <label></label>
              <label></label>
              <div id="txtFirst_Name1"></div>
			</li>
			<li>
              <label >Enter Middle Name</label>
              <label>:</label>
              <input id="txtMiddle_Name" name="txtMiddle_Name" class="text"/>
              <label></label>
              <label></label>
              <div id="txtMiddle_Name1"></div>
             </li>
			 <li>
              <label >Enter Last Name</label>
              <label>:</label>
              <input id="txtLast_Name" name="txtLast_Name" class="text"/>
              <label></label>
              <label></label>	
              <div id="txtLast_Name1"></div>
             </li>
            <li>
              <label>Enter Email ID</label>
              <label>:</label>
              <input id="txxEmail_ID" name="txxEmail_ID" class="text" />
              <label></label>
              <label></label>
              <div id="txxEmail_ID1"></div>
            </li>
       
            <li>
              <label >Enter Contact NO</label>
              <label>:</label>
              <input id="ttxContact_NO" name="ttxContact_NO" class="text" />
              <label></label>
              <label></label>
              <div id="ttxContact_NO1"></div>
            </li>
               <li>
              <label >Date Of Application</label>
              <label>:</label>
              <input type="text" name="txtDate_of_Application" id="date" class="text" />
              <label></label>
              <label></label>
			 <div id="txtDate_of_Application1"></div>
             </li>             
            <li>
			<li>
              
              <label >Select Job Vacancy</label>
              <label>:</label>
              <select name="cmbJob_Vacancy"  id="cmbJob_Vacancy" class="selectbox">
                  <option value="select">Select</option>
                  <?php  $select ="SELECT * FROM vacancy";
				   $r=mysql_query($select,$cn); 
				   while($l=mysql_fetch_array($r))
				   {?>
                  <option value="<?php echo $l[0];?>"><?php echo $l[2];?></option>
                  <?php }?>
                </select>
              <label></label>
              <label></label>
		 <div id="cmbJob_Vacancy1"></div>
            </li>
             <li>
             <label >Candidate Resume</label>
             <label>:</label>
             <input type="file" name="pdffile_name" class="text"/>
              <label></label>
              <label></label>
              <div id="pdffile_name1"></div>
              </li>
              <li>
              <li>
              <label >Keyword</label>
              <label>:</label>
              <input type="text" size="30" name="txtKeyword" id="txtKeyword" class="text" />
              <label></label>
              <label></label>
			 <div id="txtKeyword1"></div>
             </li>
             <li>
             <label >Comment</label>
             <label>:</label>
             <textarea name="txtComment" style="width:280px" id="txtComment" class="textarea"></textarea></li>
              <label></label>
			  <div id="txtComment1"></div>
              </li>
            <li class="buttons">
             <input class="submit" type="submit" name="btnsubmit" value="SUBMIT" style="margin-left:300px;width:100px;height:35px">
              <input class="submit" type="reset" name="btnreset" value="RESET" style="width:100px;height:35px;margin-left:15px;">              
            </li>
        </form>
		</div>
		</div>
		<div class="right_resize" style="margin-right:25px;">
        <div class="right" >
          <h2><span>News</span></h2>
         
			<table>
			<?php 
				$cn=getCon();
				$s="Select * from news order by Priority limit 0,2";
				$r=mysql_query($s,$cn)or die(mysql_error());
				
				while($l=mysql_fetch_array($r))
				{?>
				<tr>
				<td>
			<img src="Admin\images\news\<?php echo $l[5];?>" width="100px" height="100px" alt="News" />
			</td>
			<td width="60px" >
                <h4 style="height:100%;width:200% "><a href="#"><u><?php echo $l[3];?></u></a></h4>
                <marquee direction="up" height="70px" width="120%"><p style="color:#060"><?php echo (substr($l[4],0,20))."<br>".(substr($l[4],21,40))."<br>".(substr($l[4],41,60))."<br>".(substr($l[4],61,80));  ?>
</p></marquee>                </td>
  
				</tr>
               <tr>
				<td colspan="2">
				<div class="fp_news_date"><?php echo $l[6]; ?></div>
				</td></tr>
				<div class="cleaner"></div>
           <?php }?>
   </table>                   
        </div>
      </div >
      </div>
      </div>
  </div>
  <div class="clr"></div>
  <?php include('footer.php');?>
</div>
</body>
</html>
