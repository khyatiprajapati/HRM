<?php  include("connection.php");
$cn=getCon();
?>
<html>
<head>
<title>Usersite | Home</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/georgia.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>


		<script type="text/javascript" src="js/jquery-1.5.1.min.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		
		<!-- Nivo slider -->
		<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
		<script src="js/nivo-slider/jquery.nivo.slider.js" type="text/javascript"></script>
		<!-- ENDS Nivo slider -->		
</head>
<body>
<div class="main">
  <p>&nbsp;</p>
  <div class="header">
    <?php include('header.php');?>
	<?php include('fixsidemenu1.php');?>
    <div class="headert_text_resize_bg">
      <div class="headert_text_resize"> 
      			<div id="slider-block" style="margin-top:10px;border:solid 0px #0000FF">
				<div id="slider-holder">
					<div id="slider" style="background-color:#FFFFFF">
			<img src="images/img1.jpg" alt="" style="background-color:#FFFFFF" />
			<img src="images/img2.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img3.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img4.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img5.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img6.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img7.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img8.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img9.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img10.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img11.jpg" alt="" style="background-color:#FFFFFF"/>
			<img src="images/img12.jpg" alt="" style="background-color:#FFFFFF"/>
					</div>
				</div>
			</div>
      </div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="body" style="margin-top:30px">
    <div class="left_resize">
      <div class="left">
          <h2>Welcome to SoftMax HRM</h2>
         
          <p align="justify" style="color:#060">SoftMaxSolution specializes in delivering comprehensive technology and design solutions to its wide spectrum of clients. With our proactive approach, unflinching commitment, extensive experience and creative mindset, we achieve extraordinary results for our clients.
</p><p align="justify" style="color:#060">SoftMaxSolution is a website design and software development company. At SoftMax we don't just do the job we do it right. And perhaps it is this obsession of doing things right, along with attention to detail that brings customers back to us time and again. Our Clients are among the who's who of Global Businesses. We take great pride in our collaborations and partnerships, building lifelong relationships that are mutually beneficial.</p>
      </div>
      <div class="left">
        <h2>SoftMax Solutions</h2>
        <p align="justify" style="color:#060">A robust and features rich hosted HR system with no Download installation Maintainance or Upgrading Require And can be Setup in just 15 minutes.</p>
          </div>
      <div class="left">
        <h2>Open Source</h2>
        <p align="justify" style="color:#060">SoftMax HRM the worlds most Popular Open source Human Resource Management Software with over 1,00,000  users Globally Download.</p>
          
      </div>
      <div class="left">
        <h2>Customize</h2>
        <p align="justify" style="color:#060">SoftMax HRM Suit your requirement by addressing specific Needs our engineering team will work with you to deliver the HR system.</p>
           
      </div>
      <div class="left"><img src="images/hrm3.jpg" alt="" height="350px"  width="300px"/>
      </div>
    </div>
    <div class="right_resize">
        <div class="right">
          <h2><span>News</span></h2>
         
			<table>
			<?php 
				$cn=getCon();
				$s="Select * from news order by Priority limit 0,2";
				$r=mysql_query($s,$cn)or die(mysql_error());
				
				while($l=mysql_fetch_array($r))
				{?>
				<tr>
				<td>
			 		<img src="Admin\images\news\<?php echo $l[5];?>" width="100px" height="100px" alt="News" />
					
				</td>
			<td width="60px" >
                <h4 style="height:100%;width:200% "><a href="#"><u><?php echo $l[3];?></u></a></h4>
                <marquee direction="up" height="70px" width="120%"><p style="color:#060"><?php echo (substr($l[4],0,20))."<br>".(substr($l[4],21,40))."<br>".(substr($l[4],41,60))."<br>".(substr($l[4],61,80));  ?>
</p></marquee>                </td>

  
				</tr>
				
               <tr>
			   	
				<td colspan="2" >
				<div class="fp_news_date"><?php echo $l[6]; ?></div>
					
				</td></tr>
				<div class="cleaner"></div>
           <?php }?>
   </table>                   
        </div>
               <div class="right">
               
        <h2><span>Latest Updates</span></h2>
         <?php
				$con=getCon();
				$se="SELECT * FROM job_vacancy";	
								
				$q=mysql_query($se,$con)or die(mysql_error());
				while($l=mysql_fetch_array($q))
				{
			?>
            	<li>
				<form method="post" name="frm" id="frm">
					<?php 
							$s1="SELECT * FROM vacancy WHERE Vacancy_ID=".$l[2];					
							$q1=mysql_query($s1,$con);
							$row1=mysql_fetch_array($q1);
					?>
					<h3 style="color:#0000FF"><u><?php echo $row1[2];?></u></h3>
		 <p align="justify"><h4 style="color:#060">This vacancy is hiring By&nbsp;<?php $s2="SELECT * FROM emp_personaldetail WHERE Emp_ID=".$l[2];
						$q2=mysql_query($s2,$con)or die(mysql_error());
						$row2=mysql_fetch_array($q2);
						echo $row2[1];
						?>&nbsp; Manager of our company.
					The Basic Requirements for this vacancy is <?php echo $l[5];?></h4>	</p>				
				</form>
				</li>
				<?php } ?>
				
            	
            
        </div>
      </div >
      
      </div>
  
    <div class="clr"></div>
  </div>
  
  <div class="clr"></div>
<?php include('footer.php');?>
</div>
</body>
</html>
